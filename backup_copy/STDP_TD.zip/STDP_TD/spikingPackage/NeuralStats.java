/*
	Statistical functions for use in analyzing neural simulation results.
*/
import java.util.*;

public class NeuralStats {
	double[ ][ ] dataArray;
	double[ ][ ] spikeArray;
	double[ ] trialAve;
	double[ ] trialVar;
	int numTrials;
	int sampleTime;
	int maxCorrelLength;
	
	double[ ] selfCorrel;
	double[ ] pairCorrel;
		
/**
	Initializes the class.
*/
  	public NeuralStats(  ) {
  		numTrials = 100;
  		sampleTime = 5000;
		dataArray = new double[numTrials][sampleTime];
		spikeArray = new double[numTrials][sampleTime];
		trialAve = new double[sampleTime+1];
		trialVar = new double[sampleTime+1];
		
		selfCorrel= new double[1];
  	}
/**
	Initializes the class.
*/
  	public NeuralStats( int initNumTrials, int initSampleTime ) {
  		numTrials = initNumTrials;
  		sampleTime = initSampleTime;
		dataArray = new double[numTrials][sampleTime];
		spikeArray = new double[numTrials][sampleTime];
		trialAve = new double[sampleTime+1];
		trialVar = new double[sampleTime+1];
		
		selfCorrel= new double[1];
  	}
/**
	Sets a datum in the data set.
*/
  	public void SetDatum( int trial, int time, double newDatum ) {
		dataArray[trial][time] = newDatum;
		trialAve[sampleTime] = 0;
  	}
/**
	Gets a datum in the data set.
*/
  	public double GetDatum( int trial, int time ) {
		return dataArray[trial][time];
  	}
/**
	Sets a spike in the spike train.
*/
  	public void SetSpike( int trial, int time, boolean spike ) {
		if ( spike ) spikeArray[trial][time] = 1;
		else spikeArray[trial][time] = 0;
  	}
/**
	Gets a spike in the spike train.
*/
  	public double GetSpike( int trial, int time ) {
		return spikeArray[trial][time];
  	}
/**
	Gets the number of spikes in the sample time of the data set.
*/
  	public int GetSpikeNumber( int trial ) {
  		int spikeNum=0;
		for ( int time=0; time<sampleTime; time++ ) 
			spikeNum += (int) spikeArray[trial][time];
		return spikeNum;
  	}
/**
	Returns the time average (mean) of the data set over the sample time.
*/
  	public double TimeAverage( int trial ) {
 			double ave = 0;
			for ( int time=0; time<sampleTime; time++ ) 
				ave += dataArray[trial][time];
		return ave/sampleTime;
		
  	}
/**
	Returns the ensemble average (mean) of the data set over the trials at time.
*/
  	public double TrialAverage( int time ) {
  		double ave = 0;
		for ( int trial=0; trial<numTrials; trial++ ) 
				ave += dataArray[trial][time];
		return ave/numTrials;
		
  	}
/**
	Returns the variance of the data set.
*/
  	public double TimeVariance( int trial ) {
  		double variance = 0, ave;
  		ave = TimeAverage( trial );
		for ( int time=0; time<sampleTime; time++ ) 
			variance += ( ave - dataArray[trial][time])*( ave - dataArray[trial][time]);
		return Math.sqrt(variance/sampleTime);
		
  	}
/**
	Returns the variance of the data set.
*/
  	public double TrialVariance( int time ) {
  		double variance = 0, ave;
		for ( int trial=0; trial<numTrials; trial++ ) { 
  			ave = TrialAverage( time );
			variance += ( ave - dataArray[trial][time])*( ave - dataArray[trial][time]);
		}
		return Math.sqrt(variance/numTrials);
		
  	}
/**
	Gets maximum correlation length of the self-correlation function.
*/
  	public int GetMaxCorLength(  ) {
		return maxCorrelLength;
  	}
/**
	Compute self correlation function for a given trial.
*/
  	public void ComputeSelfCor( int initMaxCorLength, int trial ) {
  		maxCorrelLength = initMaxCorLength;
		selfCorrel= new double[maxCorrelLength];
  		double ave = TimeAverage( trial );
		for ( int s=0; s<maxCorrelLength; s++ ) {
			for ( int time=0; time<sampleTime-maxCorrelLength; time++ )
				selfCorrel[s] += (ave - dataArray[trial][time])*(ave - dataArray[trial][s+time])/sampleTime ;
		}
  		double variance = TimeVariance( trial );
		for ( int s=0; s<maxCorrelLength; s++ ) {
			if ( variance*variance != 0 ) selfCorrel[s] = selfCorrel[s]/(variance*variance);
			else selfCorrel[s] = 0;
		}
  	}
/**
	Gets self-correlation function for a given time.
*/
  	public double GetSelfCor( int time ) {
		return selfCorrel[time];
  	}
/**
	Gets joint-correlation function for a given trial.
*/
  	public double GetJointCor( NeuralStats pairData, int trial ) {
  		double corCoeff = 0;
  		double ave = TimeAverage( trial );
  		double ave2 = pairData.TimeAverage( trial );
		for ( int time=0; time<sampleTime; time++ ) {
			corCoeff += (ave - dataArray[trial][time])*(ave2 - pairData.GetDatum(trial, time))/sampleTime ;
		}
  		double variance1=0, variance2=0;
		variance1 = TimeVariance( trial );
		variance2 = pairData.TimeVariance( trial );
		if ( variance1*variance2 != 0 ) corCoeff = corCoeff/(variance1*variance2);
		else corCoeff = 0;
		return corCoeff;
  	}
}
