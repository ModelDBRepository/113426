/**
	A small neural network that can be coupled to form a larger network.
	@author Patrick D. Roberts, Neuro. Sci. Inst. OHSU, 03/01 (Supported by R01-MH60364) 
*/
import java.util.*;

public class Module{
	protected Random	randomizer;
	protected HandyFuncts funct;
	protected Waveform epspWave;
	protected Waveform ipspWave;
	protected Waveform ruleWaveB;
	protected Waveform ruleWaveF;
	protected Waveform ruleWave;
	protected int noise, thresh;
	protected int numInputSyns;
	protected int numNeurons;
	protected Soma[] neuron;
	protected PostSynapse[][] synapse;
	protected boolean[] postSpike;
	protected boolean[][] preSpike;
	protected int cycleLength;
	
	
/**
	Class constructor default.
*/
	public Module() {
	    cycleLength = 200;
	}
	
/**
	Class constructor that sets the number of neurons in the Module.
	@param numNeurons The initial number of neurons in the Module.
*/
	public Module( int numNeurons ) {
	    cycleLength = 200;
	}
	
/**
	Sets the cycleLength of a Module.
*/
	public void setCycleLength( int newCycleLength  ) {
		cycleLength = newCycleLength;
	}
/**
	Adds a synaptic connection between two neurons in the Module.
	@param preNeuron The presynaptic neuron's number in the Module.
	@param postNeuron The postsynaptic neuron's number in the Module.
*/
	public void Synapse( int preNeuron, int postNeuron ) {
/*	
		PreSynapse pre = new PreSynapse();
		preSynapses.addElement( pre );
		PostSynapse post = new PostSynapse();
		postSynapses.addElement( post );
*/
	}
/**
	Initializes the object following the default class constructor that sets the noise and spike threshold.
	@param initNoise The initial noise level.
	@exception initThreshold The initial spike threshold level ( 0 < initThreshold < 100 ).
*/
	public void initSoma( int neuronNum, int initNoise, int initThreshold )  {
		neuron[neuronNum].initSoma( initNoise, initThreshold );
	}
/**
	Gets the number of synaptic inputs to a Module.
*/
	public int getNumInputs(  ) {
		return numInputSyns;
	}
/**
	Gets the number of synaptic inputs to a Module.
	@param inputNum Which input weight to get.
*/
	public int getInputWeight( int neuronNum, int inputNum ) {
		return synapse[neuronNum][inputNum].getWeight();
	}
/**
	Sets the input spikes to a Module.
	@param inputNum Which input spike to set.
	@param spike State of the spike (true/false).
*/
	public void setInputSpike( int neuronNum, int inputNum, boolean spike ) {
			preSpike[neuronNum][inputNum] = spike;
	}
/**
	Gets the input spikes to a Module.
	@param inputNum Which input spike to get.
*/
	public boolean getInputSpike( int neuronNum, int inputNum ) {
			return preSpike[neuronNum][inputNum];
	}
/**
	Sets the epsp input weight to a neuron in the Module.
	@param neuronNum Which neuron's input weight to set.
	@param spike Synaptic weight on input epsp.
*/
	public void setEpspInput( int neuronNum, int weight ) {
			neuron[neuronNum].epspInput( weight );
	}
/**
	Sets the ipsp input weight to a neuron in the Module.
	@param neuronNum Which neuron's input weight to set.
	@param spike Synaptic weight on input epsp.
*/
	public void setIpspInput( int neuronNum, int weight ) {
			neuron[neuronNum].ipspInput( weight );
	}
/**
	Gets the epsp input weight for a neuron in the Module.
	@param neuronNum Which neuron.
	@param inputNum Which weight of input epsp.
*/
	public int getEpspInput( int neuronNum, int inputNum ) {
			return synapse[neuronNum][inputNum].getWeight( );
	}
/**
	Gets the epsp input waveform for a neuron in the Module.
	@param neuronNum Which neuron.
*/
	public Waveform getEpspWaveform( int neuronNum ) {
			return neuron[neuronNum].getEpsp( );
	}
/**
	Gets the ipsp input waveform for a neuron in the Module.
	@param neuronNum Which neuron.
*/
	public Waveform getIpspWaveform( int neuronNum ) {
			return neuron[neuronNum].getIpsp( );
	}
/**
	Returns the learning rule waveform of the synapse for pre->post.
	@param neuronNum Which neuron.
	@param inputNum Which input epsp.
*/
  	public Waveform getRule( int neuronNum, int inputNum   ) {
		return synapse[neuronNum][inputNum].getRule( );
  	}
/**
	Returns the learning rule waveform of the synapse for post->pre.
	@param neuronNum Which neuron.
	@param inputNum Which input epsp.
*/
  	public Waveform getBRule( int neuronNum, int inputNum   ) {
		return synapse[neuronNum][inputNum].getBRule( );
  	}
/** 
	Checks for a postSpike and updates the epsp input weights to a neuron in the Module.
	@param neuronNum Which neuron.
*/
	public void spikeUpdate( int neuronNum, int time ) {
		postSpike[neuronNum] = neuron[neuronNum].getSpikeINC();
		for ( int j=0; j<numInputSyns; j++ ) {	
			synapse[neuronNum][j].setPostSpikes( postSpike[neuronNum], time );
			synapse[neuronNum][j].weightUpdate( time );
		}
	}
/** 
	Checks for a postSpike and updates the epsp input weights to a neuron in the Module.
	@param neuronNum Which neuron.
*/
	public void spikeINC( int neuronNum, int time ) {
		postSpike[neuronNum] = neuron[neuronNum].getSpikeINC();
		for ( int j=0; j<numInputSyns; j++ ) {	
			synapse[neuronNum][j].setSpikesINC( preSpike[neuronNum][j], postSpike[neuronNum], time );
			synapse[neuronNum][j].updateWeight( time );
		}
	}
/** 
	Checks for a postSpike and updates the epsp input weights to a neuron in the Module.
	@param neuronNum Which neuron.
*/
	public void spike( int neuronNum, int input, int time ) {
		postSpike[neuronNum] = neuron[neuronNum].getSpikeT( time );
		synapse[neuronNum][input].setSpikes( preSpike[neuronNum][input], postSpike[neuronNum], time );
	}
/** 
	Checks for a postSpike and updates the epsp input weights to a neuron in the Module.
	@param neuronNum Which neuron.
*/
	public void spike( int neuronNum, int time ) {
		postSpike[neuronNum] = neuron[neuronNum].getSpikeT( time );
		for ( int j=0; j<numInputSyns; j++ ) {	
			synapse[neuronNum][j].setSpikes( preSpike[neuronNum][j], postSpike[neuronNum], time );
		}
	}
/**
	Checks for a postSpike and updates the epsp input weights to a neuron in the Module.
	@param neuronNum Which neuron.
*/
	public void spikeNonPlastINC( int neuronNum ) {
		postSpike[neuronNum] = neuron[neuronNum].getSpikeINC();
		for ( int j=0; j<numInputSyns; j++ ) 
			synapse[neuronNum][j].setSpikesINC( preSpike[neuronNum][j], postSpike[neuronNum] );
	}
/**
	Checks for a postSpike and updates the epsp input weights to a neuron in the Module.
	@param neuronNum Which neuron.
*/
	public void nonSpikeNonPlastINC( int neuronNum ) {
		neuron[neuronNum].getSpikeINC();
		for ( int j=0; j<numInputSyns; j++ ) 	
			synapse[neuronNum][j].setSpikesINC( preSpike[neuronNum][j], false );
	}
/** 
	Forces a postSpike and updates the epsp input weights to a neuron in the Module.
	@param neuronNum Which neuron.
*/
	public void forceSpikeINC( int neuronNum, int time, boolean spike ) {
		neuron[neuronNum].getSpikeINC();
		postSpike[neuronNum] = spike;
		for ( int j=0; j<numInputSyns; j++ ) {	
			synapse[neuronNum][j].setSpikesINC( preSpike[neuronNum][j], postSpike[neuronNum] );
			synapse[neuronNum][j].updateWeight( time );
		}
	}
/** 
	Checks for a postSpike and updates the epsp input weights to a neuron in the Module.
	@param neuronNum Which neuron.
*/
	public void updateWeight( int neuronNum, int input, int time ) {
		if (time%cycleLength==(cycleLength-1) && time>(cycleLength-1))
		 		synapse[neuronNum][input].updateWeight( );
	}
/**
	Applies a homogeneous Poisson distribution of input spikes to a neuron in the Module.
	@param neuronNum Which neuron.
	@param prob Spike probability.
*/
	public void poissonInput( int neuronNum, int prob ) {
		for ( int j=0; j<numInputSyns; j++ ){
			setInputSpike( neuronNum, j, false );
	  		float ranFloat = 100*randomizer.nextFloat();
	  		if ( ranFloat < prob ) {   
				if ( synapse[neuronNum][j].getType() == 1 ) setEpspInput( neuronNum, getInputWeight( neuronNum, j ) );
				if ( synapse[neuronNum][j].getType() == -1 ) setIpspInput( neuronNum, getInputWeight( neuronNum, j ) );
				setInputSpike( neuronNum, j, true );
			}
		}
	}
/**
	Applies a homogeneous Poisson distribution of input spikes to a neuron in the Module.
	@param neuronNum Which neuron.
	@param prob Spike probability.
*/
	public void poissonInput( int neuronNum, int prob, int scale ) {
		for ( int j=0; j<numInputSyns; j++ ){
			setInputSpike( neuronNum, j, false );
	  		float ranFloat = scale*randomizer.nextFloat();
	  		if ( ranFloat < prob ) {   
				if ( synapse[neuronNum][j].getType() == 1 ) setEpspInput( neuronNum, getInputWeight( neuronNum, j ) );
				if ( synapse[neuronNum][j].getType() == -1 ) setIpspInput( neuronNum, getInputWeight( neuronNum, j ) );
				setInputSpike( neuronNum, j, true );
			}
		}
	}
/**
	Applies a series of delayed input spikes to a neuron in the Module.
	@param neuronNum Which neuron.
	@param time Time delay following beginning of cycle.
*/
	public void serialInput( int neuronNum, int time ) {
		for ( int j=0; j<numInputSyns; j++ ) setInputSpike( neuronNum, j, false );
			if ( time < numInputSyns){
				if ( synapse[neuronNum][time].getType() == 1 ) setEpspInput( neuronNum, getInputWeight( neuronNum, time ) );
				if ( synapse[neuronNum][time].getType() == -1 ) setIpspInput( neuronNum, getInputWeight( neuronNum, time ) );
				setInputSpike( neuronNum, time, true );
			}
	}
/**
	Applies a specified input spike to a neuron in the Module.
	@param neuronNum Which neuron.
	@param input Which input.
*/
	public void specifiedInput( int neuronNum, int input, boolean spike ) {
		if ( spike ) {
			if ( synapse[neuronNum][input].getType() == 1 ) setEpspInput( neuronNum, getInputWeight( neuronNum, input ) );
			if ( synapse[neuronNum][input].getType() == -1 ) setIpspInput( neuronNum, getInputWeight( neuronNum, input ) );
			setInputSpike( neuronNum, input, true );
		}
		else setInputSpike( neuronNum, input, false );
	}
/**
	Applies a specified input spike to a neuron in the Module.
	@param neuronNum Which neuron.
	@param input Which input.
*/
	public void setInputSpk( int neuronNum, int input, boolean spike, int time ) {
		if ( spike ) {
			if ( synapse[neuronNum][input].getType() == 1 ) setEpspInput( neuronNum, getInputWeight( neuronNum, input ) );
			if ( synapse[neuronNum][input].getType() == -1 ) setIpspInput( neuronNum, getInputWeight( neuronNum, input ) );
			setPreSpike( neuronNum, input, true, time );
		}
		else setPreSpike( neuronNum, input, false, time );
	}
/**
	Sets the input spikes to a Module.
	@param inputNum Which input spike to set.
	@param spike State of the spike (true/false).
*/
	public void setPreSpike( int neuronNum, int inputNum, boolean spike, int time ) {
			preSpike[neuronNum][inputNum] = spike;
			synapse[neuronNum][inputNum].setPreSpikes( spike, time );
	}
/**
	Gets the present postsynaptic spike of a neuron.
	@param neuronNum Which neuron.
*/
	public boolean getPostSpike( int neuronNum ) {
		return postSpike[neuronNum];
	}
/**
	Gets the present postsynaptic potential of a neuron.
	@param neuronNum Which neuron.
*/
	public int getPotDiff( int neuronNum ) {
		return neuron[neuronNum].getPotDiff( );
	}

/**
	Gets the present postsynaptic potential of a neuron.
	@param neuronNum Which neuron.
*/
	public int getPot( int neuronNum ) {
		return neuron[neuronNum].getPot( );
	}
/**
	Gets the present postsynaptic potential bias of a neuron.
	@param neuronNum Which neuron.
*/
	public int getBias( int neuronNum ) {
		return neuron[neuronNum].getBias( );
	}

/**
	Sets the present postsynaptic potential bias of a neuron.
	@param neuronNum Which neuron.
*/
	public void setBias( int neuronNum, int newBias ) {
		 neuron[neuronNum].setBias( newBias );
	}

/**
	Sets the threshold of a neuron.
	@param neuronNum Which neuron.
*/
	public void setThreshold( int neuronNum, int threshold ) {
		neuron[neuronNum].setThreshold( threshold );
	}
/**
	Sets the factor to add derivative of membrane potential to spike calculation for a neuron.
	@param neuronNum Which neuron.
*/
	public void setDiffPot( int neuronNum, int newDiffPot ) {
		neuron[neuronNum].setDiffPot( newDiffPot );
	}
/**
	Gets the threshold of a neuron.
	@param neuronNum Which neuron.
*/
	public int getThreshold( int neuronNum ) {
		return neuron[neuronNum].getThreshold( );
	}
/**
	Sets the refractory period of a neuron.
	@param neuronNum Which neuron.
*/
	public void setRefractory( int neuronNum, int refractory ) {
		neuron[neuronNum].setRefractory( refractory );
	}
/**
	Gets the threshold of a neuron.
	@param neuronNum Which neuron.
*/
	public int getRefractory( int neuronNum ) {
		return neuron[neuronNum].getRefractory( );
	}
/**
	Sets the background membrane potential of a neuron.
	@param neuronNum Which neuron.
*/
	public void setBaselinePot( int neuronNum, Waveform baselinePot ) {
		neuron[neuronNum].setBaselinePot( baselinePot );
	}
/**
	Initializes the background membrane potential of a neuron to zero.
	@param neuronNum Which neuron.
*/
	public void initBaselinePot( int neuronNum ) {
		neuron[neuronNum].initBaselinePot( );
	}
/**
	Returns a the spike probability of neuron neuronNum.
	@param neuronNum Postsynaptic neuron.
*/
	public int getSpikeProb( int neuronNum ) {
		return neuron[neuronNum].getSpikeProb( );
	}
/**
	Simple synaptic interaction between neurons in the Module.
	@param preNeuron Presynaptic neuron.
	@param postNeuron Postsynaptic neuron.
	@param strength Synaptic strength of connection (If strength>=0 => epsp, else ipsp).
*/
	public void synapticConnect( int preNeuron, int postNeuron, int strength ) {
		if ( strength >= 0 ) {
			if ( postSpike[preNeuron] ) neuron[postNeuron].epspInput( strength  );
		}
		else{
			if ( postSpike[preNeuron] ) neuron[postNeuron].ipspInput( -strength  ); 
		}
	}
	
/**
	Simple synaptic interaction between neurons in the Module.
	@param preNeuron Presynaptic neuron.
	@param postNeuron Postsynaptic neuron.
	@param strength Synaptic strength of connection (If strength>=0 => epsp, else ipsp).
	@param shift time-shift of the interaction.
*/
	public void synapticConnect( int preNeuron, int postNeuron, int strength, int shift ) {
		if ( strength >= 0 ) {
			if ( postSpike[preNeuron] ) neuron[postNeuron].epspInput( strength, shift  );
		}
		else{
			if ( postSpike[preNeuron] ) neuron[postNeuron].ipspInput( -strength, shift  ); 
		}
	}
	
/**
	Returns a the spike probability of neuron neuronNum.
	@param neuronNum Postsynaptic neuron.
*/
	public void ipspInput(  int postNeuron, int strength ) {
		 neuron[postNeuron].ipspInput( strength );
	}
}


