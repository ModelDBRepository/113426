/**
	An array of long integers with periodic boundry conditions.
	@author Patrick D. Roberts, Neuro. Sci. Inst. OHSU, 11/00 (Supported by R01-MH60364) 
*/
import java.util.*;

public class Waveform {
	private int[] dataVector;
	private int length;
	
/**
	Class constructor default at 200 data points.
*/
	public Waveform() {
		dataVector = new int[200];
		length = 200;
	}
	
/**
	Class constructor that sets the number of data points.
	@param initLength The length of the array.
*/
	public Waveform( int initLength ) {
		dataVector = new int[initLength];
		length = initLength;
	}
	
/**
	Class constructor that sets the range of data points from low to high.
	@param low The lowest point in the range of the waveform.
	@param high The highest point in the range of the waveform.
*/
	public Waveform( int low, int high ) {
		dataVector = new int[high - low];
		length = high - low;
	}
	
/**
	Sets the range of data points and initializes the array.
	@param low The lowest point in the range of the waveform.
	@param high The highest point in the range of the waveform.
*/
  	public void setRange( int low, int high  ) {
		setLength( high - low );
  	}

/**
	Sets the datum at a given data point in the array.
	@param datum The datum of interest.
	@param point The array element where the datum is found.
*/
  	public void setWavePt(int datum, int point ) {
  		if ( 0 <= point ) {
    		point=point%length;
    		dataVector[point] = datum;
    	}
    	else {
    		while ( point < 0 ) point += length;
    		dataVector[point] = datum;
    	}
  	}
  	
/**
	Gets the datum at a given data point in the array (first point index=0).
	@param point The array element where the datum is found.
	@return The datum of interest.
*/
  	public int getWavePt( int point ) {
  		if ( 0 <= point ) {
    		point=point%length;
    		return dataVector[point];
    	}
    	else {
    		while ( point < 0 ) point += length;
    		return dataVector[point];
    	}
  	}
  	
/**
	Returns a copy of this waveform.
	@param wave Wave to be copied.
*/
  	Waveform getCopy(  Waveform wave  ) {
  		Waveform newWave = new Waveform( wave.getLength( ) );
		for ( int i=0; i<wave.getLength( ); i++ ) {
			newWave.setWavePt( wave.getWavePt(i), i);
		}
		return newWave;
  	}

/**
	Sets every element to a specified value.
	@param constValue The value to be set.
*/
  	public void setConstant(  int constValue  ) {
		for ( int i=0; i<length; i++ ) {
			setWavePt( constValue, i );
		}
  	}

/**
	Returns a copy of two waveforms merged front to back.
	@param wave Wave to be copied.
*/
  	public Waveform getMerge(  Waveform backWave, Waveform forwardWave  ) {
  		Waveform newWave = new Waveform( backWave.getLength( )+forwardWave.getLength( ) + 1 );
  		
		for ( int i=0; i<forwardWave.getLength( ); i++ ) 
			newWave.setWavePt( forwardWave.getWavePt(i), i);
			
		for ( int i=1; i<backWave.getLength( ); i++ ) 
			newWave.setWavePt( backWave.getWavePt(i), -i);

		return newWave;
  	}

/**
	Private method to set length.
*/
  	void setLength(  int initLength  ) {
		dataVector = new int[initLength];
		length = initLength;
  	}

/**
	Private method to get length.
*/
  	int getLength( ) {
    	return length;
  	}

}

