/**
	A set of integer functions that are useful for spiking neurons.
	@author Patrick D. Roberts, Neuro. Sci. Inst. OHSU, 11/00 (Supported by R01-MH60364) 
*/
import java.lang.Math;

 public class HandyFuncts {
	
/**
	Returns scale times the Gaussian function of integer param with variance sigma: 
	scale*exp[-param^2/sigma^2]
	@param param the input parameter.
	@param sigma The variance.
*/
  	public int Gaussian( int param, int sigma, int scale  ) {
			double dParam = param;
			double dSigma = sigma;
			double x =  scale*Math.exp( - (dParam*dParam)/(dSigma*dSigma) );
			return (int) Math.round( x );
  	}

/**
	Returns scale times the exponential function of integer param with time constant sigma: 
	scale*exp[-param/sigma]
	@param param The input parameter.
	@param sigma The variance.
*/
  	public int scaledExp( int param, int sigma, int scale  ) {
  		if ( param >= 0 ) {
			double dParam = param;
			double dSigma = sigma;
			double x =  scale*Math.exp( - dParam/dSigma );
			return (int) Math.round( x );
		}
		else return 0;
  	}
/**
	Returns scale times a normalized exponential function Waveform with time constant sigma: 
	(scale/integral)*exp[-param/sigma]
	@param param The input parameter.
	@param sigma The variance.
*/
  	public Waveform expWave( int sigma, int scale  ) {
  		int i=1, norm=0;
  		int length=1;
  		while ( i != 0 ) { // get length
  			i = scaledExp( length, sigma, scale  )/sigma;
			length++;
		}
  		Waveform wave = new Waveform( length );
  		for ( int j=0; j<length; j++ ) { // add normed values to wave
			wave.setWavePt( scaledExp( j, sigma, scale  )/sigma, j );
		}
		return wave;
  	}

/**
	Returns scale times a normalized exponential function Waveform with time constant sigma, convolved with itself 'conv' times: 
	(scale/integral)*exp[-param/sigma]
	@param param The input parameter.
	@param sigma The variance.
*/
  	public Waveform expConvWave( int sigma, int scale, int conv  ) {
  		int i=1, norm=0;
  		double power = 0, x, tau;
  		int length=1, pwr;
  		while ( i != 0 ) { // get length
  			x = (double) length;
  			tau = (double) sigma;
  			power = Math.pow( x, (double) conv-1);
  			pwr = (int) Math.round(power);
  			i = pwr*scaledExp( length, sigma, scale  )/sigma;
			length++;
		}
  		Waveform wave = new Waveform( length );
  		for ( int j=0; j<length; j++ ) { // add normed values to wave
  			x = (double) length;
  			tau = (double) sigma;
  			power = Math.pow( x/tau, (double) conv-1);
  			pwr = (int) Math.round(power);
			wave.setWavePt( pwr*scaledExp( j, sigma, scale  )/sigma, j );
		}
		return wave;
  	}

/**
	Returns scale times the Alpha function of integer param with variance sigma: 
	scale*exp[-param/sigma]
	@param param The input parameter.
	@param sigma The variance.
*/
  	public int Alpha( int param, int sigma, int scale  ) {
  		if ( param > 0 ) {
			double dParam = param;
			double dSigma = sigma;
			double x =  scale*dParam*Math.exp( - dParam/dSigma );
			return (int) Math.round( x );
		}
		else return 0;
  	}
/**
	Returns scale times a normalized Alpha function of integer param with variance sigma: 
	(scale/integral)*exp[-param/sigma]
	@param param The input parameter.
	@param sigma The variance.
*/
  	public Waveform alphaWave( int sigma, int scale  ) {
  		int i=1, norm=0;
  		int length=1;
  		while ( i != 0 ) { // get length
  			i = Alpha( length, sigma, scale  )/(sigma*sigma-sigma+1);
			length++;
		}
  		Waveform wave = new Waveform( length );
  		for ( int j=0; j<length; j++ ) { // add normed values to wave
			wave.setWavePt( Alpha( j, sigma, scale  )/(sigma*sigma-sigma+1), j );
		}
		return wave;
  	}

/**
	Returns 100 times the y-value of a sigmoid function [0, 1] 
	given the x-value and a noise parameter, 1/sigma: 100/(1+exp[-x/sigma])
	@param x The input parameter.
	@param sigma The variance.
*/
  	public int Sigmoid( int param, int sigma  ) {
		double dParam = param;
		double dSigma = sigma;
		double y =  100/(1+Math.exp( - dParam/dSigma ));
		return (int) Math.round( y );
  	}
/**
	Returns 100 times the y-value of a sigmoid function [0, 1] 
	given the x-value and a noise parameter, 1/sigma: 100/(1+exp[-x/sigma])
	@param x The input parameter.
	@param sigma The variance.
*/
  	public int LinearThreshold( int param, int sigma  ) {
		double dParam = param;
		double dSigma = sigma;
		double y =  100*( 0.5 + 0.25*(1/dSigma)*dParam );
		if ( y>0 ) return (int) Math.round( y );
		else return 0;
  	}

/**
	Returns the integral of a Waveform.
	@param wave The Waveform to integrate.
*/
  	public int Integrate( Waveform wave ) {
  		int area = 0;
		for ( int i=0; i<wave.getLength(); i++ )  area=area + wave.getWavePt(i);
		return area;
  	}
/**
	Returns the convolution of a Waveform with a Waveform representing the kernel.
	@param wave The Waveform to convolve.
	@param kernel The Waveform representing the kernel.
*/
  	public Waveform Convolve( Waveform wave, Waveform kernel ) {
  		int sum;
  		Waveform newWave = new Waveform( wave.getLength() + kernel.getLength() );
  		for ( int j=0; j<kernel.getLength(); j++ ) {
  			sum = 0;
			for ( int i=0; i<wave.getLength(); i++ ) {
				if ( (j-i) >= 0 )  sum += kernel.getWavePt(j-i)*wave.getWavePt(i);
			}
				newWave.setWavePt( sum, j );
		}
		return newWave;
  	}
/**
	Returns the convolution of a Waveform with a Waveform representing the kernel.
	@param wave The Waveform to convolve.
	@param kernel The Waveform representing the kernel.
*/
  	public Waveform DoubleConvolve( Waveform wave, Waveform kernel ) {
  		int sum;
  		Waveform newWave = new Waveform( kernel.getLength() + wave.getLength() );
  		for ( int j=0; j<kernel.getLength(); j++ ) {
  			sum = 0;
			for ( int i=0; i<wave.getLength(); i++ ) {
				for ( int k=0; k<wave.getLength(); k++ ) {
					if ( (j-i) >= 0 && (i-k) >= 0 )  sum += kernel.getWavePt(j-i)*wave.getWavePt(i-k);
				}
			}
				newWave.setWavePt( sum, j );
		}
		return newWave;
  	}
/**
	Returns a normalized exponential function Waveform with time constant sigma convolved with itself n-1 times: 
	(scale/integral)*exp[-param/sigma]
	@param param The input parameter.
	@param sigma The variance.
*/
  	public double expN( int sigma, int n, int t  ) {
		double denom = sigma*Factorial(n-1 );
		double x = t;
		double dSigma = sigma;
		double result;
		result = Math.pow( (double) x/(dSigma), (double) n-1)*Math.exp( - x/dSigma )/denom;
//		return (int) Math.round( result );
		return result;
  	}
/**
	Returns scale times a normalized exponential function Waveform with time constant sigma convolved with itself n-1 times: 
	(scale/integral)*exp[-param/sigma]
	@param param The input parameter.
	@param sigma The variance.
*/
  	public double scaledExpN( int sigma, int scale, int n, int t  ) {
		double denom = sigma*Factorial(n-1 )/scale;
		double x = t;
		double dSigma = sigma;
		double result;
		result = Math.pow( (double) x/(dSigma), (double) n-1)*Math.exp( - x/dSigma )/denom;
//		return (int) Math.round( result );
		return result;
  	}
/**
	Returns the positive side of scale times a normalized gaussian function Waveform with time constant sigma. 
	@param param The input parameter.
	@param sigma The variance.
*/
  	public Waveform  scaledExpNWave( int sigma, int scale, int n  ) {
  		int i=1, norm=0;
  		int length=1;
  		while ( i != 0 ) { // get length
  			i = (int) scaledExpN( sigma, scale, n, length )/sigma;
			length++;
		}
  		Waveform wave = new Waveform( length );
  		for ( int j=0; j<length; j++ ) { // add normed values to wave
  			i = (int) scaledExpN( sigma, scale, n, length )/sigma;
			wave.setWavePt( i, j );
		}
		return wave;
  	}
/**
	Returns a Gamma distribution of order n and mean dSigma/n, and C.V. = 1/sqrt(n): 
	(scale/integral)*exp[-param/sigma]
	@param dSigma The mean.
	@param n The order.
	@param x the interval.
*/
  	public double Gamma( double dSigma, double n, double x  ) {
		double result;
		double norm = ( dSigma*Factorial((int) n-1) );
		result = Math.pow(  x/dSigma, n-1)*Math.exp( - x/dSigma )/norm;
		if (x<0) return 0;
		return result;
  	}
/**
	Returns scale times an inverse function Waveform with time constant scale: 
	scale*(x/width)^(n-1)*exp[-x/sigma]
	@param param 	The width.
	@param scale 	The scale.
	@param n 		The n-1 power of x.
*/
  	public Waveform GammaWave(  int param, int scale, int n  ) {
			double dParam = param;
			double dScale = scale;
			double d_n = n;
  		int i=1, norm=0;
  		int length=10;
  		while ( i != 0 ) { // get length
  			i = (int) (dScale*Gamma( dParam, d_n, length ));
			length++;
		}
  		Waveform wave = new Waveform( length );
  		for ( int j=0; j<length; j++ ) { // add normed values to wave
			wave.setWavePt( (int) (dScale*Gamma( dParam, d_n, (double) j  )), j );
		}
		return wave;
  	}
/**
	Returns scale times an inverse function Waveform with time constant scale: 
	scale*(1/t)
	@param param 	The width.
	@param scale 	The scale.
	@param n 		The n-1 power of x.
	@param shift 	The shift of the origin.
	@param back 	For left shift (shift<0), the remainder of the curve.
*/
  	public Waveform GammaWave(  int param, int scale, int n, int shift, boolean back  ) {
			double dParam = param;
			double dScale = scale;
			double d_n = n;
  		int i=1, norm=0;
  		int length=10;
  		while ( i != 0 ) { // get length
  			i = (int) (dScale*Gamma( dParam, d_n, length ));
			length++;
		}
  		Waveform wave = new Waveform( 1 );
 		if ( !back ) {
 			if ( length+shift <= 0 ) return wave;
 		 	wave = new Waveform( length+shift );
  			for ( int j=0; j<length+shift; j++ ) { // add normed values to wave
				wave.setWavePt( (int) (dScale*Gamma( dParam, d_n, (double) (j-shift)  )), j );
			}
		}
 		if ( back && shift<=0 )  {
 		 	wave = new Waveform( -shift );
  			for ( int j=0; j<-shift; j++ ) { // add normed values to wave
				wave.setWavePt( (int) (dScale*Gamma( dParam, d_n, (double) (-j-shift)  )), j );
			}
		}
		int sum=0;
		for ( int j=0; j<wave.getLength(); j++ ) sum += wave.getWavePt( j );
		if ( sum == 0 || wave.getLength() == 0 ) wave = new Waveform( 1 );
		return wave;
  	}
/**
	Returns the factorial of a number (n!): 
	@param n input integer.
*/
  	public int Factorial( int n  ) {
  		int result = n;
  		if (n<2) {result = 1; n=1;}
  		while ( n != 1 ) { // get length
			n--;
  			result = result*n;
		}
		return result;
  	}
/**
	Returns scale times the inverse function of integer param: 
	scale*(1/param)
	@param param The input parameter.
	@param scale The scale.
*/
  	public int Inverse( int param, double scale  ) {
  		if ( param == 0 ) return (int) Math.round( 2*100*scale );
  		if ( param > 0 ) {
			double dParam = param;
			double dScale = scale;
			double x =  100*scale/dParam;
			return (int) Math.round( x );
		}
		else return 0;
  	}
/**
	Returns scale times an inverse function Waveform with time constant scale: 
	scale*(1/t)
	@param scale The scale.
*/
  	public Waveform InverseWave( double scale  ) {
  		int i=1;
  		int length=1;
  		while ( i != 0 ) { // get length
  			i = (int) Math.round( Inverse( length, scale  ) );
			length++;
		}
  		Waveform wave = new Waveform( length );
  		for ( int j=0; j<length; j++ ) { // add normed values to wave
			wave.setWavePt( Inverse( j, scale  ), j );
		}
		return wave;
  	}
/**
	Returns the positive side of scale times a normalized gaussian function Waveform with time constant sigma. 
	scale*exp[-(x+shift)^2/sigma^2]
	@param param The input parameter.
	@param sigma The variance.
*/
  	public Waveform gaussianWave( int sigma, int scale, int shift  ) {
  		int i=1, sum=0;
  		int length=0;
  		while ( i != 0 ) { // get length
  			i = Gaussian( length , sigma, scale  )/sigma;
			length++;
		}
		Waveform wave = new Waveform( 1 );
		if (shift>=0) {
			wave = new Waveform( length+shift );
  			for ( int j=0; j<length+shift; j++ ) { 		// full Gaussian
				wave.setWavePt( Gaussian( j - shift, sigma, scale  )/sigma, j );
			}
		}
		else {
			wave = new Waveform( length-shift );
  			for ( int j=0; j<length+shift; j++ ) { 		// full Gaussian
				wave.setWavePt( Gaussian( j - shift, sigma, scale  )/sigma, j );
			}
		}
		sum=0;
		for ( int j=0; j<wave.getLength(); j++ ) sum += wave.getWavePt( j );
		if ( sum == 0 ) wave = new Waveform( 1 );
		return wave;
  	}
}