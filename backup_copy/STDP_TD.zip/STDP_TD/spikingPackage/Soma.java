/**
	A noisy box that receives synaptic input and generates spikes.
	@author Patrick D. Roberts, Neuro. Sci. Inst. OHSU, 11/00 (Supported by R01-MH60364) 
*/
import java.util.*;

public class Soma {
	private Waveform epsp;
	private Waveform ipsp;
	private SpikeGenerator spiker;
	private MembranePot memPot;
	private int bias, diffPot;
	private int refractory, refractCounter, relRefract;
	private Waveform refractFunct;
  	private	int refractScale;
	
/**
	Class constructor default.
*/
	public Soma() {
		HandyFuncts funct = new HandyFuncts();
		Waveform wave = funct.alphaWave( 5, 100 );
		epsp = new Waveform();
		setEpsp( wave );
		wave = funct.alphaWave( 5, -100 );
		ipsp = new Waveform();
//		setIpsp( wave );
		spiker = new SpikeGenerator();	
		memPot = new MembranePot();
		refractCounter = refractory;
		refractFunct = funct.expWave( 6, 105 );
		relRefract = refractFunct.getLength();
		refractScale = 0;
	}
	
/**
	Class constructor that sets the noise and spike threshold.
	@param initNoise The initial noise level.
	@exception initThreshold The initial spike threshold level ( 0 < initThreshold < 100 ).
*/
	public Soma( int initNoise, int initThreshold ) {
		HandyFuncts funct = new HandyFuncts();
		Waveform wave = funct.alphaWave( 5, 20 );
		epsp = new Waveform();
		setEpsp( wave );
		wave = funct.alphaWave( 5, -100 );
		ipsp = new Waveform();
//		setIpsp( wave );
		spiker = new SpikeGenerator( initNoise, initThreshold );	
		memPot = new MembranePot();
		refractCounter = refractory;
		refractFunct = funct.expWave( 6, 105 );
		relRefract = refractFunct.getLength();
		refractScale = 0;
	}
	
/**
	Initializes the object following the default class constructor that sets the noise and spike threshold.
	@param initNoise The initial noise level.
	@exception initThreshold The initial spike threshold level ( 0 < initThreshold < 100 ).
*/
	public void initSoma( int initNoise, int initThreshold ) {
		spiker = new SpikeGenerator( initNoise, initThreshold );	
		refractCounter = refractory;
	}
	
/**
	Sets the baseline membrane potential.
	@param baselinePot The new baseline membrane potential waveform.
	@exception length of newWave must be the same as the original.
*/
	public void setBaselinePot( Waveform baselinePot ) {
		memPot.setBaseline( baselinePot );
	}
	
/**
	Initializes the baseline membrane potential to zero.
*/
	public void initBaselinePot( ) {
		memPot.initBaseline( );
	}
	
/**
	Sets the bias of the membrane potential.
	@param newBias The new bias of the membrane potential.
*/
	public void setBias( int newBias ) {
		bias = newBias;
	}
/**
	Gets the bias of the membrane potential.
*/
	public int getBias( ) {
		return bias;
	}
//====== EPSP methods ============================
	
/**
	Sets the epsp waveform of the soma.
	@param initEpsp The initial epsp waveform.
*/
  	public void setEpsp( Waveform newEpsp  ) {
  		epsp = newEpsp;
  	}
/**
	Gets the epsp waveform of the soma.
	@param initEpsp The initial epsp waveform.
*/
  	public Waveform getEpsp(   ) {
		return epsp;
  	}
/**
	Starts an epsp waveform of the soma.
	@param weight The initial epsp waveform ( 0 < weight < 10000 ).
*/
  	public void epspInput( int weight  ) {
			memPot.addWaveform( epsp, weight );
  	}
/**
	Starts a shifted epsp waveform of the soma.
	@param weight The initial epsp waveform ( 0 < weight < 10000 ).
	@param shift Time-shift of the epsp.
*/
  	public void epspInput( int weight, int shift  ) {
			memPot.addWaveform( epsp, weight, shift );
  	}
//====== IPSP methods ============================
	
/**
	Sets the ipsp waveform of the soma.
	@param initIpsp The initial ipsp waveform.
*/
  	public void setIpsp( Waveform newIpsp  ) {
  		ipsp = newIpsp;
/*  		int y=1;
  		int x=1;
  		while ( y > 0 ) {
			y =  newIpsp.getWavePt( x );
			ipsp.setWavePt( y, x );
			x++;
		}*/
  	}
/**
	Gets the ipsp waveform of the soma.
	@param initIpsp The initial ipsp waveform.
*/
  	public Waveform getIpsp(   ) {
		return ipsp;
  	}
/**
	Starts an ipsp waveform of the soma.
	@param weight The initial ipsp waveform ( 0 < weight < 10000 ).
*/
  	public void ipspInput( int weight  ) {
			memPot.addWaveform( ipsp, weight );
  	}
/**
	Starts an ipsp waveform of the soma.
	@param weight The initial ipsp waveform ( 0 < weight < 10000 ).
	@param shift Time-shift of the ipsp.
*/
  	public void ipspInput( int weight, int shift  ) {
			memPot.addWaveform( ipsp, weight, shift );
  	}
//=======================================
/**
	Checks if there is a spike in the present time step, given a spike threshold.
	@param newThreshold The spike threshold passed to the generator ( 0 < newThreshold < 100 ).
*/
  	public boolean getSpike( int spkThreshold ) {
  	boolean spike = false;
  	int temp = getThreshold( );
  	setThreshold( spkThreshold );
	int memPotential = memPot.getPot() + bias;
//------ Add derivative of memPot------	
	if ( diffPot > 0) {
		memPotential = memPotential + diffPot*memPot.getPotDiff()/10 ;
		if (memPotential > 10000 ) memPotential = 10000 ;
	}
//-----------------	
 	if ( spiker.getSpike( memPotential ) ) spike = true;
  	setThreshold( temp );
	return spike;
  	}
/**
	Checks if there is a spike in the present time step and INCREMENTS.
*/
  	public boolean getSpikeINC( ) {
		int memPotential = memPot.getPotIncrement() + bias;
//------ Add derivative of memPot------	
	if ( diffPot > 0) {
		memPotential = memPotential + diffPot*memPot.getPotDiff()/10 ;
		if (memPotential > 10000 ) memPotential = 10000 ;
	}
//-----------------	
 		if ( refractCounter >= refractory ) {
 			if ( spiker.getSpike( memPotential ) ) {
 				refractCounter = 0;
 				memPot.addWaveform( refractFunct, -refractScale*100 );
				return true;
			}
			else {
				refractCounter++;
				return false;
		    }
//......................... 		    
		}
		else refractCounter++;
		return false;
  	}
/**
	Checks if there is a spike in the present time step, and sets the new time.
*/
  	public boolean getSpikeT( int time ) {
		int memPotential = memPot.getPot( time ) + bias;
//------ Add derivative of memPot------	
	if ( diffPot > 0) {
		memPotential = memPotential + diffPot*memPot.getPotDiff()/10 ;
		if (memPotential > 10000 ) memPotential = 10000 ;
	}
//-----------------	
 		if ( refractCounter >= refractory ) {
 			if ( spiker.getSpike( memPotential ) ) {
 				refractCounter = 0;
 				memPot.addWaveform( refractFunct, -refractScale*100 );
				return true;
			}
			else {
				refractCounter++;
				return false;
		    }
//......................... 		    
		}
		else refractCounter++;
		return false;
  	}
/**
	Gets the membrane potential at the present time step.
*/
  	public int getPot( ) {
		return memPot.getPot() + bias;
  	}
/**
	Gets the membrane potential at the present time step.
*/
  	public int getPotDiff( ) {
		return memPot.getPotDiff() ;
  	}
/**
	Gets the spike threshold at the present time step.
*/
  	public int getThreshold( ) {
		return spiker.getThreshold() ;
  	}
/**
	Sets the spike threshold at the present time step.
	@param newThreshold The spike threshold of the generator ( 0 < newThreshold < 100 ).
*/
  	public void setThreshold( int newThreshold ) {
		spiker.setThreshold( newThreshold ) ;
  	}
/**
	Sets the current sensitivity of the spike threshold.
	@param newThreshold The spike threshold of the generator ( 0 < newThreshold < 100 ).
*/
  	public void setDiffPot( int newDiffPot ) {
		diffPot = newDiffPot;
  	}
/**
	Sets the refractory period of the spike generator.
	@param newRefractory The refractory of the generator.
*/
  	public void setRefractory( int newRefractory ) {
		refractory = newRefractory;
		refractCounter = refractory;
  	}
/**
	Gets the refractory of the spike generator.
*/
  	public int getRefractory( ) {
		return refractory;
  	}
/**
	Get the spike probability.
*/
  	public int getSpikeProb( ) {
		return spiker.getSpikeProb( getPot( ) );
  	}
/**
	Get the spike probability.
*/
  	public int getSpikeProb( int spkThreshold ) {
  		int spkProb;
  		int temp = getThreshold( );
  		setThreshold( spkThreshold );
		int memPotential = memPot.getPot() + bias;
//------ Add derivative of memPot------	
		if ( diffPot > 0) {
			memPotential = memPotential + diffPot*memPot.getPotDiff()/10 ;
			if (memPotential > 10000 ) memPotential = 10000 ;
		}
//-----------------	
		spkProb = spiker.getSpikeProb( memPotential, spkThreshold );
  		setThreshold( temp );
		return spkProb;
  	}
/**
	Sets the relative refractory function waveform of the soma.
	@param newRefractFunct The new relative refractory function waveform.
*/
  	public void setRelRefract( Waveform newRefractFunct, int newRefScale  ) {
		refractFunct = newRefractFunct;
		relRefract = refractFunct.getLength();
		refractScale = newRefScale;
  	}
  	public void relRefract(   ) {
			memPot.addWaveform( refractFunct, refractScale );
  	}
/**
	Changes the sigmoid probability curve to a linear threshold in the spike generator.
*/
  	public void LinearProbCurve( ) {
		spiker.LinearProbCurve( ) ;
  	}
}
  	

