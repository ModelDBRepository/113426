/**
	Takes a stream of spikes and the time step, and bins them according to preset rules.
	@author Patrick D. Roberts, Neuro. Sci. Inst. OHSU, 10/01 (Supported by R01-MH60364) 
*/
import java.util.*;

public class SpikeBin {
	private int time;  	
	private int tStep;  	
	private int numBins;		
	private int cycleLength;		
	private int binWidth;
	private Waveform bins;
	
/**
	Class constructor default.
*/
	public SpikeBin(  ) {
		tStep = 1;
		numBins = 360;
		cycleLength = 360;
		binWidth = cycleLength/numBins;
		bins = new Waveform( numBins );
	}
	
/**
	Class constructor that sets the cycle length in msec. 
	@param initCycleLength Must be multiple of numBins.
*/
	public SpikeBin( int initCycleLength ) {
		tStep = 1;
		numBins = 360;
		cycleLength = initCycleLength;
		binWidth = cycleLength/numBins;
		bins = new Waveform( numBins );
	}
		
/**
	Class constructor that sets the cycle length in msec. 
	@param initCycleLength Must be multiple of numBins.
*/
	public SpikeBin( int initCycleLength, int initNumBins ) {
		tStep = 1;
		numBins = initNumBins;
		cycleLength = initCycleLength;
		binWidth = cycleLength/numBins;
		bins = new Waveform( numBins );
	}
		
/**
	Class constructor that sets the cycle length in msec. 
	@param initCycleLength Must be multiple of numBins.
*/
	public SpikeBin( double initStimFreq ) {
		tStep = 1;
		numBins = 360;
		double doubleCycleLength = (1000/initStimFreq)/numBins;
		cycleLength = Math.round( (float) doubleCycleLength)*numBins;
		binWidth = cycleLength/numBins;
		bins = new Waveform( numBins );
	}
		
/**
	Initialize the bins to zero.
*/
	public void initBin(  ) {
		bins.setConstant( 0 );
	}
	
/**
	Adds a spike.
	@param time Time of the spike.
*/
  	public void addSpike( int newTime ) {
  		time = newTime;
  		int cycleTime = time%cycleLength;
  		int binNumber = cycleTime/binWidth;
		int spikesInBin = bins.getWavePt( binNumber );
		spikesInBin++;
		bins.setWavePt( spikesInBin, binNumber );
  	}
/**
	Returns number of spikes in bin.
	@param bin Which bin.
*/
  	public int getBinCount( int binNumber ) {
		return bins.getWavePt( binNumber );
  	}
/**
	Returns the spike frequency represented by the number of spikes in each bin.
	@param bin Which bin.
*/
  	public int getBinFreq( int binNumber ) {
		int spikeNum = getBinCount( binNumber );
		int cycleNum = time/cycleLength + 1;
		spikeNum = spikeNum*1000;
		return spikeNum/(binWidth*cycleNum);
  	}
/**
	Returns the spike frequency represented by the number of spikes in each bin.
	@param bin Which bin.
	@param tStep duration fo time steps.
*/
  	public int getBinFreq( int binNumber, int tStep ) {
		int spikeNum = getBinCount( binNumber );
		int cycleNum = time/cycleLength + 1;
		spikeNum = spikeNum*1000;
		return spikeNum/(binWidth*cycleNum*tStep);
  	}
/**
	Returns cycleLength.
*/
  	public int getCycleLength( ) {
		return cycleLength;
  	}
}

