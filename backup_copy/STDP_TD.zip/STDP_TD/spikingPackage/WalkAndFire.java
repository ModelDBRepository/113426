/**
	A noisy box that receives synaptic input and generates spikes.
	@author Patrick D. Roberts, Neuro. Sci. Inst. OHSU, 11/00 (Supported by R01-MH60364) 
*/
import java.util.*;

public class WalkAndFire extends Soma{
	private int memPot;
	private int epsc, ipsc;
	private int threshold;
	private SpikeGenerator spiker;
	private int decayPos, decayNeg;
	private int restingPot;
	
/**
	Class constructor default.
*/
	public WalkAndFire() {
		memPot = 0;
		epsc = 100;
		ipsc = 100;
		threshold = 50*100;
		spiker = new SpikeGenerator();	
		decayPos = 10;
		decayNeg = 10;
		restingPot = 0;
	}
	
/**
	Class constructor that sets the noise and spike threshold.
	@param initNoise The initial noise level.
	@exception initThreshold The initial spike threshold level ( 0 < initThreshold < 100 ).
*/
	public WalkAndFire( int initNoise, int initThreshold ) {
		memPot = 0;
		epsc = 100;
		ipsc = 100;
		threshold = initThreshold*100;
		spiker = new SpikeGenerator( initNoise, initThreshold );	
		decayPos = 10;
		decayNeg = 10;
		restingPot = 0;
	}
	
/**
	Initializes the object following the default class constructor that sets the noise and spike threshold.
	@param initNoise The initial noise level.
	@exception initThreshold The initial spike threshold level ( 0 < initThreshold < 100 ).
*/
	public void initWalkAndFire( int initNoise, int initThreshold ) {
		threshold = initThreshold*100;
		spiker = new SpikeGenerator( initNoise, initThreshold );	
	}
	
//====== EPSC methods ============================
	
/**
	Sets the epsc of the neuron.
	@param initEpsp The initial epsp waveform.
*/
  	public void setEpsc( int newEpsc  ) {
  		epsc = newEpsc;
  	}
/**
	Gets the epsc of the neuron.
	@param initEpsp The initial epsp waveform.
*/
  	public int getEpsc(   ) {
		return epsc;
  	}
/**
	Steps in response to an excitatory synaptic spike.
*/
  	public void epscInput( ) {
		memPot = memPot + epsc;
  	}
/**
	Steps in response to an excitatory synaptic spike.
	@param weight The initial epsp waveform ( 0 < weight < 10000 ).
*/
  	public void epscInput( int weight  ) {
		memPot = memPot + weight*epsc;
  	}
//====== IPSC methods ============================
	
/**
	Sets the ipsc of the neuron.
	@param initIpsp The initial ipsp waveform.
*/
  	public void setIpsc( int newIpsc  ) {
  		ipsc = newIpsc;
  	}
/**
	Gets the ipsc of the neuron.
	@param initIpsp The initial ipsp waveform.
*/
  	public int getIpsc(   ) {
		return ipsc;
  	}
/**
	Steps in response to an inhibitory synaptic spike.
*/
  	public void ipscInput( ) {
		memPot = memPot - ipsc;
  	}
/**
	Steps in response to an inhibitory synaptic spike.
	@param weight The initial epsp waveform ( 0 < weight < 10000 ).
*/
  	public void ipscInput( int weight  ) {
		memPot = memPot - weight*ipsc;
  	}
//=======================================
/**
	Checks if there is a spike in the present time step, and adds decay to memPot.
	If there is a post-spike, then subtracts threshold from memPot.
*/
  	public boolean Step(  ) {
  	boolean spike = false;
	if (  memPot > 10000 ) memPot = 10000;
	if (  memPot < 0 ) memPot = 0;
 	if ( spiker.getSpike( memPot ) ) {
 		spike = true;
 		memPot = memPot - threshold;
 	}
	if ( memPot >= restingPot ) memPot = memPot - (memPot-restingPot)/decayPos;
	if ( memPot < restingPot ) memPot = memPot - (memPot-restingPot)/decayNeg;
	return spike;
  	}
/**
	Checks if there is a spike in the present time step, and adds decay to memPot.
	If there is a post-spike, then subtracts threshold from memPot.
*/
  	public int StepSpikeless(  ) {
	if (  memPot > 10000 ) memPot = 10000;
	if (  memPot < 0 ) memPot = 0;
  	int spkProb = spiker.getSpikeProb( memPot ) ;
	if ( memPot >= restingPot ) memPot = memPot - (memPot-restingPot)/decayPos;
	if ( memPot < restingPot ) memPot = memPot - (memPot-restingPot)/decayNeg;
	return spkProb;
  	}
/**
	Checks if there is a spike in the present time step, and adds decay to memPot.
	If there is a post-spike, then subtracts threshold from memPot.
*/
  	public int StepSpikeless( int drag ) {
	if (  memPot > 10000 ) memPot = 10000;
	if (  memPot < 0 ) memPot = 0;
  	int spkProb = spiker.getSpikeProb( memPot ) ;
  	int newPot = memPot;
	if ( memPot >= restingPot ) newPot = memPot - (memPot-restingPot)/decayPos;
	if ( memPot < restingPot ) newPot = memPot - (memPot-restingPot)/decayNeg;
	memPot = newPot + (newPot-memPot)/drag;
	return spkProb;
  	}
/**
	Gets the membrane potential at the present time step.
*/
  	public int getPot( ) {
		return memPot;
  	}
/**
	Sets the membrane potential at the present time step.
*/
  	public void setPot( int newPot ) {
		 memPot = newPot;
  	}
/**
	Gets the resting membrane potential at the present time step.
*/
  	public int getRestingPot( ) {
		return restingPot;
  	}
/**
	Gets the spike threshold at the present time step.
*/
  	public int getThreshold( ) {
		return spiker.getThreshold() ;
  	}
/**
	Sets the spike threshold at the present time step.
	@param newThreshold The spike threshold of the generator ( 0 < newThreshold < 100 ).
*/
  	public void setThreshold( int newThreshold ) {
		threshold = newThreshold*100;
		spiker.setThreshold( newThreshold ) ;
  	}
/**
	Get the spike probability.
*/
  	public int getSpikeProb( ) {
		return spiker.getSpikeProb( getPot( ) );
  	}
/**
	Sets the decay step size.
*/
  	public void setDecay( int newDecay ) {
		decayPos = newDecay;
		decayNeg = newDecay;
  	}
/**
	Sets the decay step size.
*/
  	public void setDecay( int newDecayPos, int newDecayNeg ) {
		decayPos = newDecayPos;
		decayNeg = newDecayNeg;
  	}
/**
	Changes the sigmoid probability curve to a linear threshold in the spike generator.
*/
  	public void LinearProbCurve( ) {
		spiker.LinearProbCurve( ) ;
  	}
/**
	Sets the resting membrane potential at the present time step.
*/
  	public void setRestingPot(int newRestingPot ) {
		restingPot = newRestingPot;
  	}
}
  	

