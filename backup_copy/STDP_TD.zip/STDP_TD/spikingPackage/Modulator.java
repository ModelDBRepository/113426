/**
	A set of integer functions that are useful for spiking neurons.
	@author Patrick D. Roberts, Neuro. Sci. Inst. OHSU, 11/00 (Supported by R01-MH60364) 
*/
import java.lang.Math;
import java.util.*;

 public class Modulator {
 	int period, cycleTime;
 	double ampl, modulation;			// amplitude of modulation
	HandyFuncts funct;
// 	Random randomGen;
//	double rand;
 
 /**
	Initializes the class.
*/
  	public Modulator() {
  		period = 200;
  		ampl = 0.5;		
		funct = new HandyFuncts();
//		randomGen = new Random();
//		rand = randomGen.nextDouble();
  	}
/**
	Initializes the class.
	@param initPeriod The initial period of modulation.
	@param initAmplitude The initial amplitude of modulation.
*/
  	public Modulator( int initPeriod, double initAmplitude ) {
  		period = initPeriod;
  		ampl = initAmplitude;		
		funct = new HandyFuncts();
//		randomGen = new Random();
//		rand = randomGen.nextDouble();
  	}
/**
	Set the mean and width of the distribution: 
	@param initPeriod The new period of modulation.
	@param initAmplitude The new amplitude of modulation.
*/
  	public void SetParams( int initPeriod, double initAmplitude  ) {
  		period = initPeriod;
  		ampl = initAmplitude;		
  	}
/**
	Returns a sine-function of time.  
	@param time The present time-step.
*/
  	public double Sine( int time  ) {
		return ampl*Math.sin(2*Math.PI*( (double) time)/period);
  	}
/**
	Returns a step-function of time. 
	@param time The present time-step.
*/
  	public double Step(  int time  ) {
  		cycleTime = time%period;
		if ( cycleTime > period/4 && cycleTime < 3*period/4 ) return ampl;
		else return -ampl;
  	}
/**
	Modulate the mean while adjusting the width to maintain the randomness: 
	@param time The present time-step.
	@param slope The slope of the rise of the trapizoid function.
*/
  	public double Trapezoid(  int time, double slope  ) {
  		cycleTime = time%period;
		if ( cycleTime < period/2 ) modulation = slope*( cycleTime - period/4 );
		else modulation = -slope*( cycleTime - 3*period/4 );
		if ( modulation < -ampl ) return -ampl;
		if ( modulation > ampl ) return ampl;
		return modulation;
  	}
 }