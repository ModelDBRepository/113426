/**
	An array of integers with periodic boundry conditions 
	where data goes in and can be selected and retrieved in reverse order.
	@author Patrick D. Roberts, Neuro. Sci. Inst. OHSU, 11/00 (Supported by R01-MH60364) 
*/
import java.util.*;

public class MembranePot {
	private int[] dataVector;
	private int[] baselineVector;
	private int length;
	private int now;
	
/**
	Class constructor default at 200 data points.
*/
	public MembranePot( ) {
		dataVector = new int[200];
		baselineVector = new int[200];
		length = 200;
	}
	
/**
	Class constructor that sets the number of data points.
	@param initLength The length of the array.
*/
	public MembranePot( int initLength ) {
		dataVector = new int[initLength];
		baselineVector = new int[initLength];
		length = initLength;
	}
	
/**
	Class constructor that sets the baseline wave and equal number of data points.
	@param baselineWave The initial baseline wave.
*/
	public MembranePot( Waveform baselineWave ) {
		dataVector = new int[baselineWave.getLength( )];
		baselineVector = new int[baselineWave.getLength( )];
  		for ( int i=0; i<baselineWave.getLength( ); i++ ) {
  			baselineVector[i] = (int) baselineWave.getWavePt(i);
  		}
		length = baselineWave.getLength( );
	}
	
/**
	Sets the baseline wave if there are an equal number of data points as the old one.
	@param newWave The new baseline wave.
	@exception length of newWave must be the same as the original.
*/
  	public void setBaseline( Waveform newWave ) {
  		if ( newWave.getLength( ) != length ) 
  			throw new RuntimeException ( "New baseline wave length does not match original." );
  		for ( int i=0; i<length; i++ ) {
  			baselineVector[i] = ( int ) newWave.getWavePt(i);
  		}
  	}
  	
/**
	Initializes the baseline wave to zero.
*/
  	public void initBaseline(  ) {
  		for ( int i=0; i<length; i++ )  baselineVector[i] = 0;
  	}
  	
/**
	Adds waveform beginning at the present time step, then forward in time.
	@param wave The wave, such as an epsp, added to the membrane potential.
*/
  	public void addWaveform( Waveform wave ) {
     	int point;
		int waveLength = wave.getLength( );
 		for ( int i=0; i<waveLength; i++ ) {
 			point=(now+i)%length;
    		dataVector[point] = dataVector[point] + ( int ) wave.getWavePt(i);
    		if ( dataVector[point] > 10000 ) dataVector[point] = 10000;
//    		if ( dataVector[(now+i)%length] < 0 ) dataVector[(now+i)%length] = 0;
   		}
  	}
  	
/**
	Adds scaled waveform beginning at the present time step, then forward in time.
	@param wave The wave, such as an epsp, added to the membrane potential.
	@param scale The scale of the wave.
*/
  	public void addWaveform( Waveform wave, int scale ) {
     	int point;
     	double value;
		int waveLength = wave.getLength( );
 		for ( int i=0; i<waveLength; i++ ) {
 			point=(now+i)%length;
//    		dataVector[point] = dataVector[point] + ( int ) scale*wave.getWavePt(i)/100;
     	Integer intVal = new Integer( scale*wave.getWavePt(i) );
//    		value =  ( double ) intVal;
    		value =  intVal.doubleValue();
    		dataVector[point] = dataVector[point] + ( int ) value/100;
    		if ( dataVector[point] > 10000 ) dataVector[point] = 10000;
   		}
  	}
  	
/**
	Adds scaled waveform beginning at the present time step, then forward in time.
	@param wave The wave, such as an epsp, added to the membrane potential.
	@param scale The scale of the wave.
	@param shift The shift of the wave.
*/
  	public void addWaveform( Waveform wave, int scale, int shift ) {
     	int point;
     	double value;
		int waveLength = wave.getLength( );
 		for ( int i=0; i<waveLength; i++ ) {
 			point=(now+i+shift+length)%length;
//    		dataVector[point] = dataVector[point] + ( int ) scale*wave.getWavePt(i)/100;
    		value =  ( double ) scale*wave.getWavePt(i);
    		dataVector[point] = dataVector[point] + ( int ) value/100;
    		if ( dataVector[point] > 10000 ) dataVector[point] = 10000;
   		}
  	}
  	
/**
	Gets the membrane potential at the present time step.
*/
  	public int getPot( ) {
    	int point = now%length;
    	int sum = dataVector[point] + baselineVector[point];
    	return sum;
  	}
  	
/**
	Gets the membrane potential at the present time step.
*/
  	public int getPot( int time ) {
    	now = time;
    	int erasePoint = (now - 3 + length)%length;  // erase 3 steps back for accurate PotDiff.
    	int point = (erasePoint+3)%length;
    	int sum = dataVector[point] + baselineVector[point];
    	dataVector[erasePoint] = 0;	// erase 3 steps back for accurate PotDiff.
    	return sum;
  	}
  	
/**
	Gets the membrane potential at the present time step, and INCREMENTS the time step.
*/
  	public int getPotIncrement( ) {
    	int erasePoint = (now - 3 + length)%length;  // erase 3 steps back for accurate PotDiff.
    	int point = (erasePoint+3)%length;
    	int sum = dataVector[point] + baselineVector[point];
    	dataVector[erasePoint] = 0;	// erase 3 steps back for accurate PotDiff.
    	now++;
    	return sum;
  	}
/**
	Gets the membrane potential at the present time step.
*/
  	public int getPotDiff( ) {
    	int point0 = (now-1+length)%length;
    	int point1 = (now-3+length)%length;
    	int diff = 0;
    	int sum0, sum1;
    		sum0 = dataVector[point0] + baselineVector[point0];
    		sum1 = dataVector[point1] + baselineVector[point1];
    		diff = sum0-sum1;
    	return 2*diff;
  	}  	
}

