/**
	A set of integer functions that are useful for spiking neurons.
	@author Patrick D. Roberts, Neuro. Sci. Inst. OHSU, 11/00 (Supported by R01-MH60364) 
*/
import java.lang.Math;
import java.util.*;

 public class Afferent {
 	double meanISI;			// mean of square distrib
 	boolean isModulated;  // flag for response to modulation
 	double meanModulation;  // modulation of mean (%), 0 < meanModulation < 1.0
 	boolean spikeState;		
 	Random randomGen;
	double rand;
	HandyFuncts funct;
 	double meanRate, order, orderRatio;			// mean of square distrib
 	int spkCount;
 	double dMod, lastMod, adapt;
 
 /**
	Initializes the class.
*/
  	public Afferent() {
  		meanISI = 20;
  		isModulated = false;
		randomGen = new Random();
		rand = randomGen.nextDouble();
		funct = new HandyFuncts();
		order = 1;
  	}
/**
	Initializes the class.
	@param initMeanISI  Initial mean interspike interval.
	@param initWidth	Initial variance of the interspike interval.
*/
  	public Afferent( double initMeanISI, double initOrder ) {
  		isModulated = true;
  		meanISI = initMeanISI;
  		if (initOrder==0) order = 1;
  		else order = initOrder;
  		orderRatio = initMeanISI/order;
  		if ( orderRatio < 1 ) order = initMeanISI;
		randomGen = new Random();
		rand = randomGen.nextDouble();
		funct = new HandyFuncts();
  	}
/**
	Initializes the class.
	@param initMeanISI  Initial mean interspike interval.
	@param initWidth	Initial variance of the interspike interval.
*/
  	public Afferent( double initMeanISI, double initOrder, boolean initIsModulated ) {
  		isModulated = initIsModulated;
  		if (initOrder==0) order = 1;
  		else order = initOrder;
  		meanISI = initMeanISI;
  		orderRatio = initMeanISI/order;
  		if ( orderRatio < 1 ) order = initMeanISI;
		randomGen = new Random();
		rand = randomGen.nextDouble();
		funct = new HandyFuncts();
  	}
/**
	Set the mean and width of the distribution: 
	@param newMeanISI New mean interspike interval.
	@param newWidth New variance of the interspike interval.
*/
  	public void SetParams( double newMeanISI, double newOrder  ) {
  		meanISI = newMeanISI;
  		orderRatio = newMeanISI/newOrder;
  		if ( orderRatio < 1 ) order = newMeanISI;
  		else order = newOrder;
  	}
/**
	Get the mean of the ISI distribution: 
*/
  	public double GetMean() {
  		return meanISI+meanModulation;
  	}
/**
	Modulate the mean while adjusting the width to maintain the randomness: 
	@param modulation The present interspike interval.
	@param time The present time-step.
*/
  	public void StepAfferent( double modulation, int time  ) {
		if (isModulated) ModulateRate( modulation );
		else meanRate = (1/meanISI);
		if ( orderRatio < 0.5 ) SpikeReg( time );
		else SpikeIrreg( time );
  	}
/**
	Modulate the rate while adjusting the width to maintain the randomness: 
	@param modulation The present interspike interval.
*/
  	public void ModulateRate( double modulation  ) {
  		dMod = (1-(1/orderRatio))*(modulation-lastMod);
  		lastMod = modulation;
//  		adapt += (1/(meanISI))*(100*dMod - adapt);
  		adapt += (1/(meanISI))*(1*dMod - adapt);
  		meanRate = (1/meanISI)*( 1 + modulation + adapt );
  		if ( order > 1/meanRate ) order =  (1/meanRate);
//  		order = 1/(meanRate*orderRatio);
  	}
/**
	Get the spike: 
*/
  	public boolean GetSpike() {
  		return spikeState;
  	}
/**
	Returns spike for regular afferents: 
	@param time The present time-step.
*/
  	public boolean SpikeReg( int time  ) {
  		if ( spkCount < rand + meanISI ) {
    		spikeState = false;
			spkCount++;
 		}
  		else {
   			spikeState = true;
     		rand = (meanISI*(1-orderRatio))*randomGen.nextGaussian();
    		spkCount = 0;
  		}
  		return spikeState;
  	}
/**
	Returns spike of irregular afferents: 
	@param time The present time-step.
*/
  	public boolean SpikeIrreg( int time  ) {
    	rand = randomGen.nextDouble();
  		if ( SpikeRateProb( time  ) < rand ) {
    		spikeState = false;
 		}
  		else {
			spkCount++;
    		if ( spkCount>=order ) {
    			spikeState = true;
    			spkCount = 0;
    		}
    		else spikeState = false;
  		}
  		return spikeState;
  	}
/**
	Returns spike probability based on a Poisson point process: 
	@param time The present time-step.
*/
  	public double SpikeRateProb( int time  ) {
 		return meanRate*order; 
  	}
 }