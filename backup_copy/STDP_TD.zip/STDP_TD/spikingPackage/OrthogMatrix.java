/*
	Class that generates an orthogonal matrix.
*/
import java.util.*;

public class OrthogMatrix {
		public double[][] matrix;
		public int dim;
		
/**
	Initializes the matrix.
*/
  	public OrthogMatrix(  ) {
  		dim = 3;
		matrix = new double[dim][dim];
		GramSchmidt( false );
  	}
/**
	Initializes the matrix.
*/
  	public OrthogMatrix( int initDim ) {
  		dim = initDim;
		matrix = new double[dim][dim];
		GramSchmidt( true );
  	}
/**
	Initializes the matrix.
*/
  	public OrthogMatrix( int initDim, boolean randomMatrix ) {
  		dim = initDim;
		matrix = new double[dim][dim];
		GramSchmidt( randomMatrix );
  	}
/**
	Uses the Gram-Schmidt algorithm to generate an orthogonal-normal basis set of vectors as matrix rows.
*/
	public void GramSchmidt( boolean randomMatrix ) {
		int num;
		double digit, deciDigit;
		Random randomizer = new Random();
		digit = Math.PI;
		for (int i=0; i<dim; i++) {
			if (randomMatrix) for (int j=0; j<dim; j++)  matrix[i][j] = -randomizer.nextDouble();
			else {
				for (int j=0; j<dim; j++)  {
					num = (dim*i + j);
					deciDigit = Math.floor(digit)*10;
					digit = digit*10;
					digit = digit - deciDigit;
					matrix[i][j] = - (int) digit;
					digit = Math.sqrt(digit);
				}
			}
		}
		double[] row, rowProj, resultRow;
		double normSq, prod;
		resultRow = getRow(0);
		normSq = vectorNormSq( resultRow, dim );
		for (int n=0; n<dim; n++)  resultRow[n] = resultRow[n]/Math.sqrt(normSq);
		setRow(resultRow, 0);
		for (int i=1; i<dim; i++) {
			resultRow = getRow(i);
			row = getRow(i);
			for (int j=0; j<i; j++) {
				rowProj = getRow(j);
				normSq = vectorNormSq( rowProj, dim ); 
				prod = vectorProduct( rowProj, row, dim );
				for (int n=0; n<dim; n++)  resultRow[n] = resultRow[n]-(prod/normSq)*rowProj[n];
			}
			normSq = vectorNormSq( resultRow, dim );
			for (int n=0; n<dim; n++)  resultRow[n] = resultRow[n]/Math.sqrt(normSq);
			setRow(resultRow, i);
		}
	}
/**
	Computes the product of scalar with a vector of length N.
*/
  	public void scalarProduct( double[] vect, double scalar, int N ) {
  		double prod = 0;
  		for (int i=0; i<dim; i++) vect[i] = scalar*vect[i];
  	}
/**
	Computes the inner product of 2 vectors of length N.
*/
  	public double vectorProduct( double[] vect1, double[] vect2, int N ) {
  		double prod = 0;
  		for (int i=0; i<dim; i++) prod += vect1[i]*vect2[i];
		return prod;
  	}
/**
	Computes the  product of 2 square matricies of dimension N.
*/
  	public double[][] matrixProduct( double[][] matrix1, double[][] matrix2, int N ) {
  		double[][] result = new double[dim][dim];
  		for (int i=0; i<N; i++) {
  			for (int j=0; j<N; j++) {
  				for (int k=0; k<N; k++) result[i][j] += matrix1[i][k]*matrix2[k][j];
  			}
  		}
		return result;
  	}
/**
	Computes the square of the matrix.
*/
  	public void squareMatrix(  ) {
  		matrix = matrixProduct(  matrix, matrix, dim );
  	}
/**
	Computes the norm of a vector of length N.
*/
  	public double vectorNormSq( double[] vect, int N ) {
  		double norm = 0;
  		for (int i=0; i<dim; i++) norm += vect[i]*vect[i];
		return norm;
  	}
/**
	Gets the value at the coordinate.
*/
  	public double getElem( int m, int n ) {
		return matrix[m][n];
  	}
  	
/**
	Gets the row of the matrix.
*/
  	public double[] getRow( int m ) {
  		double[] vector = new double[dim];
  		for (int i=0; i<dim; i++) vector[i] = matrix[m][i];
		return vector;
  	}
/**
	Sets the row of the matrix to the vector.
*/
  	public void setRow( double[] vector, int m ) {
  		for (int i=0; i<dim; i++) matrix[m][i] = vector[i];
  	}
  	
/**
	Generates a matrix that rotates cartesian basis elems.
*/
  	public void PermuteBasisMatrix( int newDim ) {
  		dim = newDim;
		matrix = new double[dim][dim];
  		for (int i=1; i<dim; i++) matrix[i][i-1] = 1;
 		matrix[0][dim-1] = 1;
 	}
 	
 /**
	Generates a matrix that rotates cartesian basis elems, with swapping/inverting elems.
*/
  	public void PermuteSwapMatrix( int newDim ) {
  		dim = newDim;
		matrix = new double[dim][dim];
		double a = 1.4142;
		matrix[0][dim-1] = a;
  		for (int i=1; i<dim; i++) matrix[i-1][i] = a;
		matrix[dim-1][0] = -a;
  		for (int i=0; i<dim-1; i++) matrix[i][i+1] = -a;
  	}
  	
  	
// determinant : cofactor expansion
	public int DET(int[][] A, int n) {
		int d=0;
		if(n==1) d += A[0][0];
		else for(int k=0;k<n;k++) 
			d += (int)Math.pow(-1,k)*A[0][k]*this.DET(this.MINOR(A,n,0,k),n-1);
		return d;
	}
// minor matrix
	public int[][] MINOR(int[][] A, int n, int h, int k){
		int mA[][] = new int[n-1][n-1];
		for(int i=0;i<h;i++){
			for(int j=0;j<k;  j++) mA[i][j]=A[i][j];
			for(int j=k;j<n-1;j++) mA[i][j]=A[i][j+1];
		}
		for(int i=h;i<n-1;i++){
			for(int j=0;j<k;  j++) mA[i][j]=A[i+1][j];
			for(int j=k;j<n-1;j++) mA[i][j]=A[i+1][j+1];
		}
		return mA;
	}



}
