/*
	Statistical functions for use in analyzing neural simulation results.
*/
import java.util.*;

public class SpikeStats {
	int[ ] latencyArray;
	int initArraySize;
	int numSpikes, sampleTime;
		
	int maxCorrelLength;
		
/**
	Initializes the class.
*/
  	public SpikeStats(  ) {
  		numSpikes = 0;
  		initArraySize = 100;
  		sampleTime = 1000;
		latencyArray = new int[initArraySize];
		
  		maxCorrelLength = 35;
  	}
/**
	Initializes the class.
*/
  	public SpikeStats( int initSampleTime, int initCorrelLength ) {
  		numSpikes = 0;
  		sampleTime = initSampleTime;
  		initArraySize = 10;
		latencyArray = new int[initArraySize];
		
  		maxCorrelLength = initCorrelLength;
  	}
/**
	Initializes the class.
*/
  	public SpikeStats( int initCorrelLength ) {
  		numSpikes = 0;
  		sampleTime = 1;
  		initArraySize = 10;
		latencyArray = new int[initArraySize];
		
  		maxCorrelLength = initCorrelLength;
  	}
/**
	Sets a spike in the spike train.
*/
  	public void SetSpike( int time, boolean spike ) {
		if ( spike ) {
			if ( (numSpikes)%initArraySize == 0) {
				int[] tempArray = new int[latencyArray.length];
				System.arraycopy(latencyArray, 0, tempArray, 0, latencyArray.length);
				latencyArray = new int[latencyArray.length + initArraySize];
				System.arraycopy(tempArray, 0, latencyArray, 0, tempArray.length);
			}
			latencyArray[numSpikes] = time;
			numSpikes++;
  		}
  	}
/**
	Gets the number of spikes in the sample time of the data set.
*/
  	public int GetSpikeNumber(  ) {
		return numSpikes;
  	}
/**
	Gets the time of the num-th spike.
*/
  	public int GetLatency( int num ) {
		return latencyArray[num];
  	}
/**
	Gets the whole spike train.
*/
  	public int[] GetLatencyArray( ) {
		return latencyArray;
  	}
/**
	Gets the whole spike train.
*/
  	public void SetSampleTime( int newSampleTime ) {
  		sampleTime = newSampleTime;
  	}
/**
	Gets the number of spikes in the sample time of the data set divided by the sample time.
*/
  	public double GetSpikeProb(  ) {
  		double numSpk = (double) numSpikes;
  		double sampleTm = (double) sampleTime;
		return numSpk/sampleTm;
  	}
/**
	Returns an array that is the autocorrelogram of the spike train.
*/
  	public double[] GetAutoCorrel(  ) {
//		double[ ] autoCorrel = new double[maxCorrelLength];
		double[ ] autoCorrel;
		autoCorrel =  GetPairCorrel( this );
		autoCorrel[0] = 0;
		return autoCorrel;
  	}
/**
	Returns an array that is the pair correlogram of two spike trains.
*/
  	public double[] GetPairCorrel( SpikeStats spkStat2 ) {
		double[ ] pairCorrel = new double[maxCorrelLength];
  		int[] tempArray = new int[spkStat2.GetSpikeNumber()];
  		tempArray = spkStat2.GetLatencyArray( );
  		int spkInterval, cor, spkNumber, spkNumber2;
  		spkNumber = GetSpikeNumber();
  		spkNumber2 = spkStat2.GetSpikeNumber();
  		for ( int i=0; i<spkNumber ; i++) {
  			cor = 0;
  			while (tempArray[cor] < latencyArray[i] && cor<spkNumber2 ) cor++;
  			while (tempArray[cor] < latencyArray[i]+maxCorrelLength && cor<spkNumber2 ) {
  				spkInterval = tempArray[cor] - latencyArray[i]; 
  				pairCorrel[spkInterval]++;
  				cor++;
  			}
  		}
  		double norm =GetSpikeProb()*spkStat2.GetSpikeProb();
  		for ( int i=0; i< maxCorrelLength; i++) pairCorrel[i] = pairCorrel[i]/sampleTime - norm;
		return pairCorrel;
  	}
/**
	Returns an array that is the autocorrelogram of the spike train.

  	public double[] GetAutoCorrel(  ) {
		double[ ] autoCorrel = new double[maxCorrelLength];
  		int[] tempArray = new int[latencyArray.length];
  		int spkInterval, cor;
		System.arraycopy(latencyArray, 0, tempArray, 0, latencyArray.length);
  		for ( int i=0; i< latencyArray.length-maxCorrelLength; i++) {
  			spkInterval= 0;
  			cor= 1;
  			while ( spkInterval<maxCorrelLength && (i+cor)<tempArray.length ) {
  				spkInterval = tempArray[i+cor] - latencyArray[i]; 
  				if ( spkInterval>0 && spkInterval<maxCorrelLength ) autoCorrel[spkInterval]++;
  				cor++;
	  		}
  		}
  		double norm = (double) GetSpikeNumber()*GetSpikeNumber();
  		norm = norm/(sampleTime);
  		for ( int i=1; i< maxCorrelLength; i++) autoCorrel[i] = autoCorrel[i]/norm-1;
		return autoCorrel;
  	}
*/
/**
	Returns an array that is the pair correlogram of two spike trains.

  	public double[] GetPairCorrel( SpikeStats spkStat2 ) {
		double[ ] pairCorrel = new double[maxCorrelLength];
  		int[] tempArray = new int[spkStat2.GetSpikeNumber()];
  		tempArray = spkStat2.GetLatencyArray( );
  		int spkInterval, cor, spkNumber, spkNumber2;
  		spkNumber = GetSpikeNumber();
  		spkNumber2 = spkStat2.GetSpikeNumber();
  		for ( int i=0; i<spkNumber ; i++) {
  			for ( cor=-i;cor<spkNumber2-i ; cor++) {
  				spkInterval= -1;
//  				if ( (i+cor)>=0 && (i+cor)<spkNumber2 ) spkInterval = tempArray[i+cor] - latencyArray[i]; 
  				spkInterval = tempArray[i+cor] - latencyArray[i]; 
  				if ( spkInterval>=0 && spkInterval<maxCorrelLength ) pairCorrel[spkInterval]++;
  				if (  spkInterval>maxCorrelLength ) cor = spkNumber2;
	  		}
  		}
  		double norm =GetSpikeProb()*spkStat2.GetSpikeProb();
  		norm = norm*sampleTime;
  		for ( int i=0; i< maxCorrelLength; i++) pairCorrel[i] = pairCorrel[i]/norm -1;
		return pairCorrel;
  	}
*/
/**
	Returns an double that is the variance of the spike probability of the spike train.
*/
  	public double GetISIVar( ) {
  		double varISI = 0;
  		double aveISI = 1/GetSpikeProb();
  		for ( int i=0; i<GetSpikeNumber()-1; i++) {
  			varISI = varISI + ( aveISI - (GetLatency( i+1 )-GetLatency( i )) )*( aveISI - (GetLatency( i+1 )-GetLatency( i )) );
		}
  		varISI = Math.sqrt( varISI/GetSpikeNumber() );
		return varISI;
  	}
}
