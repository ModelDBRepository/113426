/**
	An array of long integers with periodic boundry conditions 
	where data goes in and can be selected and retrieved in reverse order.
	@author Patrick D. Roberts, Neuro. Sci. Inst. OHSU, 11/00 (Supported by R01-MH60364) 
*/
import java.util.*;

public class StreamingData {
	private int[] dataVector;
	private int length;
	private int now;
	
/**
	Class constructor default at 200 data points.
*/
	public StreamingData( ) {
		dataVector = new int[200];
		length = 200;
	}
	
/**
	Class constructor that sets the number of data points.
	@param initLength The length of the array.
*/
	public StreamingData( int initLength ) {
		dataVector = new int[initLength];
		length = initLength;
	}
	
/**
	Sets the datum at the present time step and INCREMENTS.
	@param datum The datum to be set.
*/
  	public void setDatum(int datum ) {
    	int point=now%length;
    		dataVector[point] = datum;
   		now++;
 	}
/**
	Sets the datum at the present time step and INCREMENTS.
	@param datum The datum to be set.
*/
  	public void setDatum(int datum, int time ) {
   		now = time;
    	int point=now%length;
    		dataVector[point] = datum;
 	}
  	
/**
	Sets the datum at the specified number of time steps from the present.
	@param datum The datum to be set.
	@param point The time steps from the present when the datum is to be set.
	@exception "point" must be less than zero and within the range of added data.
*/
  	public void setDatumAt(int datum, int point ) {
  		if ( 0 == point ) setDatum( datum );
  		if ( 0 < point ) throw new RuntimeException ( "Can't add data to the future." );
  		point = now + point;
  		if ( 0 <= point ) {
    		point=point%length;
    		dataVector[point] = datum;
    	}
    	else throw new RuntimeException ( "Can't add data before the beginning of time." );
  	}
  	
/**
	Gets the datum at the previous time step.
*/
  	public int getDatum( ) {
    	int point=( now-1 )%length;
    	return dataVector[point];
  	}
  	
/**
	Gets the datum at the specified number of time steps from the present.
	@param datum The time steps from the present when the datum is to be set.
	@exception time step number must be less than zero //and within the range of added data.
*/
  	public int getDatumAt( int point ) {
  		if ( 0 == point ) getDatum( );
  		if ( 0 < point ) throw new RuntimeException ( "Can't get data from the future." );
  		point = now + point;
  		if ( 0 <= point ) {
    		point=point%length;
    		return dataVector[point];
    	}
//    	else return 0;
    	else throw new RuntimeException ( "Can't get data from before the beginning of time." );
  	}
/**
	Gets the datum at the previous time step.
*/
  	public int getNow( ) {
    	return now;
  	}
  	
}

