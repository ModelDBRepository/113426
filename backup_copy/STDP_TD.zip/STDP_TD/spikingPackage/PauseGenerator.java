/**
	Generates the CFR pause consistent with [Barmack95]
	@author Patrick D. Roberts, Neuro. Sci. Inst. OHSU, 10/01 (Supported by R01-MH60364) 
*/
import java.util.*;

public class PauseGenerator {
	private double intercept;  	// a in Igor
	private double interceptDev;
	private double slope;		// b in Igor
	private double slopeDev;
  	private Random randomizer;
	
/**
	Class constructor default with intercept = 75, interceptDev = 2.5 and slopeDev = 0.2.
*/
	public PauseGenerator(  ) {
		intercept = 75;
		interceptDev = 2.5;
		slope = 0;
		slopeDev = 0.2;
		randomizer = new Random();
	}
	
/**
	Class constructor that sets the parameter values.
	@param initIntercept The y-intercept.
	@param initInterceptDev The y-intercept standard deviation.
	@param initSlope The slope.
	@param initSlopeDev The slope standard deviation.
*/
	public PauseGenerator( double initIntercept, double initInterceptDev, double initSlope, double initSlopeDev ) {
		intercept = initIntercept;
		interceptDev = initInterceptDev;
		slope = initSlope;
		slopeDev = initSlopeDev;
		randomizer = new Random();
	}
		
/**
	Returns CFR pause.
	@param memPot The membrane potential.
  	public double getPause( double ssFreq ) {
		double interceptRand = intercept + (interceptDev/1.414)*randomizer.nextGaussian();
		double slopeRand = slope + (slopeDev/1.414)*randomizer.nextGaussian();
		return interceptRand + slopeRand*ssFreq;
  	}
*/
/**
	Returns CFR pause.
	@param memPot The membrane potential.
*/
  	public long getPause( double ssFreq ) {
		double interceptRand = intercept + (interceptDev/1.414)*randomizer.nextGaussian();
		double slopeRand = slope + (slopeDev/1.414)*randomizer.nextGaussian();
		return Math.round( (float) interceptRand + slopeRand*ssFreq);
  	}
}

