/**
	A neural network base class.
	@author Patrick D. Roberts, Neuro. Sci. Inst. OHSU, 04/01 (Supported by R01-MH60364) 
*/
import java.util.*;

 public class Network {

	public int NUMNEURONS;
	public Module	module;
	
/**
	Initializes the network.
  	public Network(  ) {
  	}
*/


/**
	Initializes the object following the default class constructor that sets the noise and spike threshold.
	@param initNoise The initial noise level.
	@exception initThreshold The initial spike threshold level ( 0 < initThreshold < 100 ).
*/
	public void initSoma( int neuronNum, int initNoise, int initThreshold )  {
		module.initSoma( neuronNum, initNoise, initThreshold );
	}
/**
	Returns the number of neurons in the network.
*/
  	public int GetNumNeurons(  ) {
		return NUMNEURONS;
  	}
/**
	Returns the number of inputs to a module.
*/
  	public int getNumInputs(  ) {
		return module.getNumInputs();
  	}

/**
	Gets the epsp input weight for a neuron in the Module.
	@param neuronNum Which neuron.
	@param inputNum Which weight of input epsp.
*/
	public int getEpspInput( int neuronNum, int inputNum ) {
		return module.getEpspInput( neuronNum, inputNum );
  	}
/**
	Gets the epsp waveform for a neuron in the Module.
	@param neuronNum Which neuron.
*/
	public Waveform getEpspWaveform( int neuronNum ) {
		return module.getEpspWaveform( neuronNum );
  	}
/**
	Gets the ipsp waveform for a neuron in the Module.
	@param neuronNum Which neuron.
*/
	public Waveform getIpspWaveform( int neuronNum ) {
		return module.getIpspWaveform( neuronNum );
  	}
/**
	Returns the learning rule waveform of the synapse for pre->post.
	@param neuronNum Which neuron.
	@param inputNum Which input epsp.
*/
  	public Waveform getRule( int neuronNum, int inputNum   ) {
		return module.getRule( neuronNum, inputNum );
  	}
/**
	Returns the learning rule waveform of the synapse for post->pre.
	@param neuronNum Which neuron.
	@param inputNum Which input epsp.
*/
  	public Waveform getBRule( int neuronNum, int inputNum   ) {
		return module.getBRule( neuronNum, inputNum );
  	}
/**
	Gets the input spikes to a Module.
	@param inputNum Which input spike to get.
*/
	public boolean getInputSpike( int neuronNum, int inputNum ) {
		return module.getInputSpike( neuronNum, inputNum );
	}
/**
	Gets the present spike threshold of a neuron.
	@param neuronNum Which neuron.
*/
	public int getThreshold( int neuronNum ) {
		return module.getThreshold( neuronNum );
	}
/**
	Sets the present postsynaptic potential of a neuron.
	@param neuronNum Which neuron.
*/
	public void setThreshold( int neuronNum, int newThreshold ) {
		module.setThreshold( neuronNum, newThreshold );
	}
/**
	Gets the present postsynaptic potential of a neuron.
	@param neuronNum Which neuron.
*/
	public int getPot( int neuronNum ) {
		return module.getPot( neuronNum );
	}
/**
	Gets the present postsynaptic potential bias of a neuron.
	@param neuronNum Which neuron.
*/
	public void setBias( int neuronNum, int newBias ) {
		 module.setBias( neuronNum, newBias );
	}
/**
	Gets the present postsynaptic potential bias of a neuron.
	@param neuronNum Which neuron.
*/
	public int getBias( int neuronNum ) {
		return module.getBias( neuronNum );
	}
/**
	Gets the present postsynaptic potential of a neuron.
	@param neuronNum Which neuron.
*/
	public int getPotDiff( int neuronNum ) {
		return module.getPotDiff( neuronNum );
	}
/**
	Gets the present postsynaptic spike of a neuron.
	@param neuronNum Which neuron.
*/
	public boolean getPostSpike( int neuronNum ) {
		return module.getPostSpike( neuronNum );
	}
/**
	Returns a the spike probability of neuron neuronNum.
	@param neuronNum Postsynaptic neuron.
*/
	public int getSpikeProb( int neuronNum ) {
		return module.getSpikeProb( neuronNum );
	}
}