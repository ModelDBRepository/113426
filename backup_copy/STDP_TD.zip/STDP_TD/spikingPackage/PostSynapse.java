/**
	A weight that can change according to the time difference between spikes in a PreSynapse and a Soma.
	@author Patrick D. Roberts, Neuro. Sci. Inst. OHSU, 12/00 (Supported by R01-MH60364) 
*/
import java.util.*;

public class PostSynapse {
	private StreamingData spikeTrain;	// Record of spikes
	private Waveform preSpikes;	// Record of spikes
	private Waveform postSpikes;	// Record of spikes
	private	int preSpkNum;			// number of presynaptic spikes.
	private	int postSpkNum;			// number of postsynaptic spikes.
	private Waveform learningRule;		// pre->post
	private Waveform bRule;				//post->pre
	private int nonAssoc;				// non-associative learning rate
	private int weight;					// ( 0 < weight < 10000 )
	private int meta;				// Scale of weight dependent synaptic changes.
	private int type;					// excitatory (+1) or inhibitory (-1)
	private int updatePause;			// Waiting time since the preSpkTime until weight is updated.
	private int updateDelay;			// Waiting time between weight updates.
	private int assocWidth;				// Non-zero segment of learningRule.
	private	int preSpkTime;			// Time elapsed since the presynaptic spike.
	private	int recentPre;			// Flag for the presence of a presynapic spike during the update pause.
  	private int lowRate, highRate, globalWtChange, spkCount, time; //Global wt scaling variables.
  	private boolean globalScaling;	//Global wt scaling flag.
	protected int cycleLength;
	
/**
	Class constructor default.
*/
	public PostSynapse() {
		spikeTrain = new StreamingData();
		preSpikes = new Waveform();
		postSpikes = new Waveform();
		HandyFuncts funct = new HandyFuncts();
		Waveform wave = funct.alphaWave( 6, -100 );
		learningRule = new Waveform( wave.getLength( ) );
		setRule( wave, 15 );
		weight = 3000;
		type = 1;	
		cycleLength = 200;
	}
	
/**
	Class constructor that sets the weight.
	@param initWeight The initial weight ( 0 < weight < 10000 ).
*/
	public PostSynapse( int initWeight ) {
		spikeTrain = new StreamingData();
		preSpikes = new Waveform();
		postSpikes = new Waveform();
		HandyFuncts funct = new HandyFuncts();
		Waveform wave = funct.alphaWave( 6, -100 );
		learningRule = new Waveform( wave.getLength( ) );
		setRule( wave, 15 );
		weight = initWeight;
		if ( weight > 10000 ) weight = 10000;
		if ( weight < 1 ) weight = 1;
		type = 1;	
		cycleLength = 200;
	}
	
/**
	Class constructor that sets the weight, type, and learning rule.
	@param initWeight The initial weight ( 0 < weight < 10000 ).
	@param initType If excitatory synapse then type=1, if inhibitory then type=-1.
	@param rule Waveform that describes the weight change for any time difference between pre- and postsynaptic spikes.
*/
	public PostSynapse( int initWeight, int initType, Waveform rule, int initNonAssoc ) {
		spikeTrain = new StreamingData();
		preSpikes = new Waveform();
		postSpikes = new Waveform();
		weight = initWeight;
		if ( weight > 10000 ) weight = 10000;
		if ( weight < 1 ) weight = 1;
		type = initType;	
		learningRule = new Waveform( rule.getLength( ) );
		setRule( rule, initNonAssoc );
		cycleLength = 200;
	}
/**
	Class constructor that sets the weight, type, and learning rule, and metaScale.
	@param initWeight The initial weight ( 0 < weight < 10000 ).
	@param initType If excitatory synapse then type=1, if inhibitory then type=-1.
	@param rule Waveform that describes the weight change for any time difference between pre- and postsynaptic spikes.
*/
	public PostSynapse( int initWeight, int initType, Waveform rule, int initNonAssoc, int initMeta ) {
		spikeTrain = new StreamingData();
		preSpikes = new Waveform();
		postSpikes = new Waveform();
		weight = initWeight;
		if ( weight > 10000 ) weight = 10000;
		if ( weight < 1 ) weight = 1;
		meta = initMeta;
		type = initType;	
		learningRule = new Waveform( rule.getLength( ) );
		setRule( rule, initNonAssoc );
		cycleLength = 200;
	}
		
/**
	Sets the cycleLength of a Module.
*/
	public void setCycleLength( int newCycleLength  ) {
		cycleLength = newCycleLength;
	}
/**
	Sets the learning rule waveform of the synapse.
	@param newRule The new learning rule waveform.
	@param newNonAssoc The new non-associative learning rate.
*/
  	public void setRule( Waveform newRule, int newNonAssoc  ) {
  		learningRule = newRule;
		assocWidth = newRule.getLength();
  		int y=1;
  		int x=1;
  		while ( y != 0 ) {
			y =  newRule.getWavePt( x );
//			learningRule.setWavePt( y, x );
			x++;
		}
		updatePause = x-1;
		nonAssoc = newNonAssoc;
		for ( int i=0; i<= assocWidth; i++) spikeTrain.setDatum( 0 );
  	}
/**
	Sets the learning rule waveform of the synapse.
	@param newRule The new learning rule waveform.
	@param newNonAssoc The new non-associative learning rate.
*/
  	public void setRule( Waveform newBRule, Waveform newFRule, int newNonAssoc  ) {
  		learningRule = newFRule;
  		bRule = newBRule;
		assocWidth = newFRule.getLength();
  		int y=1;
  		int x=1;
  		while ( y != 0 ) {
			y =  newFRule.getWavePt( x );
//			learningRule.setWavePt( y, x );
			x++;
		}
		updatePause = x-1;
		nonAssoc = newNonAssoc;
		for ( int i=0; i<= assocWidth; i++) spikeTrain.setDatum( 0 );
  	}
/**
	Sets the learning rule waveform of the synapse.
	@param newRule The new learning rule waveform.
	@param newNonAssoc The new non-associative learning rate.
*/
  	public void setRuleT( Waveform newBRule, Waveform newFRule, int newNonAssoc  ) {
		int assocWidth = newBRule.getLength() + newFRule.getLength();
		learningRule = new Waveform( assocWidth );
		for ( int i=0; i<= newFRule.getLength(); i++) learningRule.setWavePt( newFRule.getWavePt( i ), i );
		for ( int i=0; i<= newBRule.getLength(); i++) learningRule.setWavePt( newBRule.getWavePt( i ), -i-1 );
		nonAssoc = newNonAssoc;
  		bRule = newBRule;
  	}
/**
	Sets the non-associative component of the learning rule.
	@param newNonAssoc The new non-associative learning rate.
*/
  	public void setNonAssoc(  int newNonAssoc  ) {
		nonAssoc = newNonAssoc;
  	}
/**
	Returns the learning rule waveform of the synapse for pre->post.
*/
  	public Waveform getRule(   ) {
		return learningRule;
  	}
/**
	Returns the learning rule waveform of the synapse for post->pre.
*/
  	public Waveform getBRule(   ) {
		return bRule;
  	}
/**
	Returns the synaptic type of the synapse (+1 => excitatory, -1=> inhibitory).
*/
  	public int getType( ) {
		return type;
  	}
/**
	Returns the synaptic weight.
*/
  	public int getWeight( ) {
		return weight;
  	}
/**
	DEPRECIATED
	Sets a presynaptic and a postsynaptic spike at time='now'and INCREMENTS.
	@param preSpike The presence of a presynaptic spike.
	@param postSpike The presence of a postsynaptic spike.
*/
  	public void setSpikesPlastINC( boolean preSpike, boolean postSpike ) {
  		int spike = 0;
  		preSpkTime++;
  		if ( preSpike ) {spike += 1; recentPre++; }
  		if ( postSpike ) spike += 2; 
  		spikeTrain.setDatum( spike );
  		if ( preSpkTime == updatePause ) { 
  			if ( recentPre > 0 ) { 
  				AssocWtChange(); 
  				NonAssocWtChange(); 
  				for ( int i=(-updatePause+1); i<=0; i++ ){
  					preSpkTime = -i;
  					if ( spikeTrain.getDatumAt( i )%2 == 1 )  break;
  				}
  				recentPre--;
  			}
  			else { preSpkTime = 0;}
   		}
  	}
/**
	Sets a presynaptic and a postsynaptic spike at time='now'and INCREMENTS.
	@param preSpike The presence of a presynaptic spike.
	@param postSpike The presence of a postsynaptic spike.
*/
  	public void setSpikesINC( boolean preSpike, boolean postSpike ) {
  		int spike = 0;
  		preSpkTime++;
  		if ( preSpike ) 
  			spike += 1;
  		if ( postSpike ) 
  			spike += 2; 
  		if ( globalScaling ) GlobalWtChange( postSpike );
  		spikeTrain.setDatum( spike );
  	}
/**
	Sets a presynaptic and a postsynaptic spike at time='now'and INCREMENTS.
	@param preSpike The presence of a presynaptic spike.
	@param postSpike The presence of a postsynaptic spike.
*/
  	public void setSpikesINC( boolean preSpike, boolean postSpike, int time ) {
  		int spike = 0;
  		preSpkTime++;
  		if ( preSpike ) 
  			spike += 1;
  		if ( postSpike ) 
  			spike += 2; 
  		if ( globalScaling ) GlobalWtChange( postSpike );
  		spikeTrain.setDatum( spike );
    //-------------------
  		if ( preSpike ) { 
  			preSpikes.setWavePt( time, preSpkNum);
  			preSpkNum++;
  		}
  		if ( postSpike ) {
  			postSpikes.setWavePt( time, postSpkNum);
  			postSpkNum++;
  		}
  	}
/**
	Sets a presynaptic and a postsynaptic spike at time='now'and INCREMENTS.
	@param preSpike The presence of a presynaptic spike.
	@param postSpike The presence of a postsynaptic spike.
*/
  	public void setSpikes( boolean preSpike, boolean postSpike, int time ) {
  		int spike = 0;
  		preSpkTime++;
  		if ( preSpike ) 
  			spike += 1;
  		if ( postSpike ) 
  			spike += 2; 
  		if ( globalScaling ) GlobalWtChange( postSpike );
  		spikeTrain.setDatum( spike, time );
  	}
/**
	Sets a presynaptic and a postsynaptic spike at time='now'and INCREMENTS.
	@param preSpike The presence of a presynaptic spike.
	@param postSpike The presence of a postsynaptic spike.
*/
  	public void setPreSpikes( boolean preSpike, int time ) {
  		if ( preSpike ) { 
  			preSpikes.setWavePt( time, preSpkNum);
  			preSpkNum++;
  		}
  	}
/**
	Sets a presynaptic and a postsynaptic spike at time='now'and INCREMENTS.
	@param preSpike The presence of a presynaptic spike.
	@param postSpike The presence of a postsynaptic spike.
*/
  	public void setPostSpikes( boolean postSpike, int time ) {
  		if ( postSpike ) {
  			postSpikes.setWavePt( time, postSpkNum);
  			postSpkNum++;
  		}
  	}
/**
	Clears the presynaptic and a postsynaptic spikes.
*/
  	public void clearSpikes(  ) {
  		for ( int j=0; j<preSpkNum; j++ )  
  			preSpikes.setWavePt( 0, j);
  		preSpkNum = 0;
  		for ( int j=0; j<postSpkNum; j++ ) 
  			postSpikes.setWavePt( 0, j);
  		postSpkNum = 0;
  	}
/**
	Updates the synaptic weight due to timing between pre- and postsynaptic spikes.
	@param time The present time step of the network.
*/
  	public void weightUpdate( int time ) {
  		updateDelay = cycleLength;
  		int preIndex, postIndex, prepost;
  		if ( time>0 && time%updateDelay == 0 ) { 
  			preIndex = 0; 
  			while ( preSpikes.getWavePt( preIndex) > 0 ) {
   				postIndex = 0;
  				while ( postSpikes.getWavePt( postIndex) > 0 ) {
  					prepost = postSpikes.getWavePt( postIndex ) - preSpikes.getWavePt( preIndex );
  					prepost = (prepost + updateDelay)%updateDelay;
 					if ( prepost>=0 && prepost<learningRule.getLength() )
 						weight += learningRule.getWavePt( prepost );
 					if ( prepost<0 && prepost<bRule.getLength() )
 						weight += bRule.getWavePt( prepost );
   					postIndex++;
				}
  				NonAssocWtChange(); 
				if ( weight > 10000 ) weight = 10000;
				if ( weight < 1 ) weight = 1;
				preIndex++;
			}
  		clearSpikes();
  		}
  	}
  	
/**
	Updates the synaptic weight due to timing between pre- and postsynaptic spikes.
	@param time The present time step of the network.
*/
  	public void updateWeight( int time ) {
  		updateDelay = 201;
  		if ( time%updateDelay == 0 && time>0) { 
			for ( int i= -updateDelay; i<=0; i++ ) {
  				if ( spikeTrain.getDatumAt( i )%2 == 1 ) {
					for ( int j= -updateDelay; j<=0; j++ ) {
						if ( meta == 0 ) {
							if ( spikeTrain.getDatumAt( j ) > 1 ) {
								if ( (Math.abs(j - i) < learningRule.getLength()) && (j - i) >= 0 ) 
									weight += learningRule.getWavePt( j - i );
								if ( (Math.abs(j - i) < bRule.getLength()) && (j - i) < 0 ) 
									weight += bRule.getWavePt( i - j );
								}
						}
						else {
							if ( spikeTrain.getDatumAt( j ) > 1 ) {
								int wtChange = 0;
								if ( (Math.abs(j - i) < learningRule.getLength()) && (j - i) >= 0 ) 
									wtChange = learningRule.getWavePt( j - i );
								if ( (Math.abs(j - i) < bRule.getLength()) && (j - i) < 0 ) 
									wtChange = bRule.getWavePt( i - j );
								if ( wtChange > 0 ) {
										wtChange = (10000-meta*weight/10)*wtChange;
										if ( wtChange>0 ) wtChange = wtChange/10000;
										else wtChange = 0;
									}
								weight += wtChange;
							}
						}
					}
  				}
			}
  			NonAssocWtChange(); 
			if ( weight > 10000 ) weight = 10000;
			if ( weight < 1 ) weight = 1;
  		}
  	}

/**
	Updates the synaptic weight due to timing between pre- and postsynaptic spikes, ONCE PER CYCLE.
	@param time The present time step of the network.
*/
  	public void updateWeight(  ) {
  		int backAssocWidth = bRule.getLength();
  		int fwrAssocWidth = learningRule.getLength() - backAssocWidth;
			for ( int i= 0; i<=cycleLength; i++ ) {
   				if ( spikeTrain.getDatumAt( i-cycleLength )%2 == 1 ) {
					for ( int j= 0; j<=cycleLength; j++ ) {
						if ( meta == 0 ) {
							if ( spikeTrain.getDatumAt( j-cycleLength ) > 1 ) {
								if ( (Math.abs(j - i) < fwrAssocWidth) && (j - i) >= 0 ) 
									weight += learningRule.getWavePt( j - i );
								if ( (Math.abs(j - i) < backAssocWidth) && (j - i) < 0 ) 
									weight += learningRule.getWavePt( i - j );
								}
						}
						else {
							if ( spikeTrain.getDatumAt( j-199 ) > 1 ) {
								int wtChange = 0;
								if ( (Math.abs(j - i) < fwrAssocWidth) && (j - i) >= 0 ) 
									wtChange = learningRule.getWavePt( j - i );
								if ( (Math.abs(j - i) < backAssocWidth) && (j - i) < 0 ) 
									wtChange = learningRule.getWavePt( i - j );
								if ( wtChange > 0 ) {
										wtChange = (10000-meta*weight/10)*wtChange;
										if ( wtChange>0 ) wtChange = wtChange/10000;
										else wtChange = 0;
									}
								weight += wtChange;
							}
						}
					}
  				}
			}
  			NonAssocWtChange(); 
			if ( weight > 10000 ) weight = 10000;
			if ( weight < 1 ) weight = 1;
  	}

/**
	DEPRECIATED
	Changes the synaptic weight due to postsynaptic activity.
*/
  	private void AssocWtChange(  ) {
		for ( int i= (-assocWidth); i<=0; i++ ) {
			if ( meta == 0 ) {
				if ( spikeTrain.getDatumAt( i ) > 1 ) 
					weight += learningRule.getWavePt( i + updatePause );
			}
			else {
				if ( spikeTrain.getDatumAt( i ) > 1 ) {
					int wtChange;
						if ( i < -updatePause ) wtChange = learningRule.getWavePt( i + updatePause );
						else {
							wtChange = meta*(10000-weight)*learningRule.getWavePt( i + updatePause );
							wtChange = wtChange/10000;
						}
					weight += wtChange;
				}
			}
		}
		if ( weight > 10000 ) weight = 10000;
		if ( weight < 1 ) weight = 1;
  	}
/**
	Changes the synaptic weight due to postsynaptic activity.
*/
  	private void NonAssocWtChange(  ) {
		weight = weight + nonAssoc;
//		if ( weight > 10000 ) weight = 10000;
//		if ( weight < 1 ) weight = 1;
  	}
/**
	Global change due to postsynaptic rate.
	@param spike The presence of a postsynaptic spike.
*/
  	private void GlobalWtChange( boolean postSpike  ) {
  		time++;
  		if ( postSpike ) spkCount++;
  		int rate = (1000*spkCount)/time;
		if ( rate < lowRate ) weight += globalWtChange;
		if ( rate > highRate ) weight -= globalWtChange;
		if ( weight > 10000 ) weight = 10000;
		if ( weight < 1 ) weight = 1;
  	}
/**
	Initialize global synaptic weight change due to postsynaptic rate.
	@param iniGlobalScaling Flag to toggle global synaptic scaling.
	@param iniLowRate Low side of rate scaling (x1000).
	@param iniHighRate High side of rate scaling (x1000).
	@param iniGlobalWtChange Amount of synaptic change.
*/
  	public void initGlobalWtChange( boolean iniGlobalScaling, int iniLowRate, int iniHighRate, int iniGlobalWtChange  ) {
  		globalScaling = iniGlobalScaling;
  		lowRate = iniLowRate;
  		highRate = iniHighRate;
  		globalWtChange = iniGlobalWtChange;
  	}
}