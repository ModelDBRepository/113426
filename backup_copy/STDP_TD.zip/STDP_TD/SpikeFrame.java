//
//  SpikeFrame.java
//

import java.awt.*;

public class SpikeFrame extends Frame {
	//Declare and define constants
	//Insert "PeriodicGraph Constants"
	protected static final int SLEEP_DELAY = 10;  
	protected static final int WIDTH = 800;
//	protected static final int HEIGHT = 530;
	protected static final int HEIGHT = 330;
	protected static final int SCALE = 10000/(HEIGHT-30);
	protected static final int CYCLELENGTH = 200;

	//Declare data members
	//Insert "PeriodicGraph data members"
	protected int time;
	protected int cycles;
	protected Image offImage;
  	protected Graphics offGraphics;
	private int[] dataVector;
	private int[] lastPot;
	private int[] wtHisto;
	private int[][] potHisto;
	
//	protected Vector files;
	protected Image currentImage;
	protected boolean isPlaying;
	protected PlayRunnable playRunnable;
	protected Thread thread;
/******===============================*******/
//	private GranGoNetwork	network;
//	private ELLNetwork	network;
	private OneNetwork1	network;
//	private ActivityNetwork	network;
/******===============================*******/

        
    public static void main(String args[]) {
	new SpikeFrame();
    }
  	public void InitNetwork() {
 /******===============================*******/
		network = new OneNetwork1();		
/******===============================*******/
		int numNeurons = network.GetNumNeurons();
//		dataVector = new int[128];
		dataVector = new int[200];
		lastPot = new int[numNeurons];
		wtHisto = new int[10];
		potHisto = new int[numNeurons][10];
		time = 0;
/*************************************/
 	}
        
    public SpikeFrame() {
	super("SpikeFrame");
		//INIT_STATE
		//Initialize state information
		InitNetwork();
		//Insert "PeriodicGraph init state"
		isPlaying = false;
		currentImage = null;
		
		//INIT_CONTROLS
		//Setup and configure our PeriodicGraph
		//Insert "PeriodicGraph init controls"
		setLayout(null);
		setVisible(false);
		setSize(WIDTH, HEIGHT);
		setLocation(0, 30);
//		setLocation((screenSize.width - WIDTH) / 2, (screenSize.height - HEIGHT) / 2);
//		setBackground(Color.white);
		setBackground(Color.black);
	Label l = new Label("Hello World!");;
	add(l);
	setVisible(true);
         togglePlaying();
    }
	/**
	 * Starts or stops cycling forward through the graph to display.
	 */
	public void togglePlaying()
	{
		//Handle starting and stopping the automatic progression of the show.
		//Insert "PeriodicGraph togglePlaying"
		if (isPlaying)
		{
			if (playRunnable != null)
				playRunnable.isRun = false;
			isPlaying = false;
		}
		else
		{
			if (thread == null || !thread.isAlive())
			{
				if (playRunnable != null)
					playRunnable.isRun = false;
					
				playRunnable = new PlayRunnable();
				thread = new Thread(playRunnable);
				thread.start();
				isPlaying = true;
			}
		}
	}
	//Inner class to implement our automatic progression of the show.
	//Insert "PeriodicGraph PlayRunnable"
	class PlayRunnable implements Runnable
	{
		public boolean isRun = true;
		
		public void run()
		{
			while (isRun)
			{
/*************************************/
		//pre-run before display
				if ( cycles*CYCLELENGTH < 00 ) {
					time++;
					if (time>=CYCLELENGTH && time <=2000) {
					time=0; 
					cycles++;}
					network.StepNetwork( cycles*CYCLELENGTH + time );
				}
				else oneStep(true);
//				if ( cycles == 0 ) oneStep(true);
/*************************************/
				if ( cycles <= 100 ) oneStep(true);
				try
				{
					Thread.sleep(SLEEP_DELAY);
				}
				catch (InterruptedException exc) { }
			}
		}
	}
	
	/**
	 * Steps the slide show forward or backwards by one image.
	 * @param if true, step forward, if false, step backward.
	 */
	public void oneStep(boolean isForward)
	{
     // Paint screen
			repaint();
	}	
	public void update(Graphics g)
	{
		//Handle drawing the image in the frame content area.

		//Handle stepping forward in the program,
		//and repainting.
//		if (time>=CYCLELENGTH) {
//		time=0; 
//		cycles++;}
//		offImage = createImage( 4, HEIGHT );
//		offImage = createImage( WIDTH, HEIGHT );
//        g = offImage.getGraphics();
	while ( time < CYCLELENGTH) {
		network.StepNetwork( cycles*CYCLELENGTH + time );
//		network.StepNetwork( cycles*CYCLELENGTH + time, -10 );
/******  Streaming graph  ************/
//	  	g.setColor( Color.white );
	  	g.setColor( Color.black );
    	g.fillRect( 4*time + 0, 0, 4, HEIGHT );
		int numNeurons = network.GetNumNeurons();
// Draw weights:		
	  for (int i=0; i<numNeurons; i++) {        
		int numInputs = network.getNumInputs();
		int cell = i;
		for ( int j=0; j<numInputs; j++ ) {
	  		int weight = network.getEpspInput( cell, j );
	  		if (weight > 9200) weight =9200;
//      		if (network.getInputSpike( cell, j ) && j==time) { 
      		if ( j==time) { 
      			if (i==0) g.setColor( Color.white );
	  			if (i>0) g.setColor( Color.red );
    			g.fillRect( 4*time, (HEIGHT-30)-(weight/SCALE), 4, 4 );
    		}
    		dataVector[j] = weight;
		}
		
	// Draw threshold:
		int thresh = 100*network.getThreshold( i );
	  	if (i==0) g.setColor( Color.gray );
	  	if (i>0) g.setColor( Color.red );
		g.drawLine( 4*time + 0, (HEIGHT-30)-(thresh/SCALE), 4*time + 2, (HEIGHT-30)-(thresh/SCALE) );
	  }
	// Draw membrane potential:
	  for (int i=0; i<numNeurons; i++) {        
	  	g.setColor( Color.red );
//	  	if (i==0) g.setColor( Color.black );
	  	if (i==0) g.setColor( Color.white );
	  	if (i==1) g.setColor( Color.blue );
	  	int pot = network.getPot( i );
//	  	int pot = network.getBias( i );
     	g.drawLine( 4*time + 0, (HEIGHT-30)-(lastPot[i]/SCALE), 4*time + 4, (HEIGHT-30)-(pot/SCALE) );
     	lastPot[i] = pot;
//     	g.setColor( Color.gray );
//    	g.fillRect( 4*time, (HEIGHT-30)-(network.getPotDiff( i )/(SCALE)), 2, 2 );  //**** draw diff pot
	// Draw postsynaptic spikes:
	  	g.setColor( Color.red );
    	if (i==0){
    		if (network.getPostSpike( 0 )){
    			g.setColor( Color.white ); 
     			g.fillRect( 4*time + 1, (HEIGHT-28+2), 3, 30 );
     		}
     	}
    	if (i==2){
    		if (network.getPostSpike( 2 )){
    			g.setColor( Color.red ); 
     			g.fillRect( 4*time + 1, (HEIGHT-28+2), 1, 30 );
     		}
     	}
	  }
     // Draw x-axis
//     	g.setColor( Color.black );
     	g.setColor( Color.white );
		g.drawLine( 4*time + 0, (HEIGHT-30+2), 4*time + 4, (HEIGHT-30+2) );
     // Draw cursor line
//		g.drawLine( 4*time + 10, 0, 4*time + 10, HEIGHT );
//******  End streaming graph  ********

/******  Histograms  **********
	// Draw weight histo:
	  for (int i=0; i<numNeurons; i++) {        
	  	g.setColor( Color.red );
	  	if (i==1) g.setColor( Color.black );
	  	int pot = network.getPot( i );
	  	int maxBin = 0;
	  	for (int bin=0; bin<10; bin++ ){
	  		if ( bin*1000 < pot && pot < (bin+1)*1000 ) potHisto[i][bin] += 1;
	  		if ( maxBin < potHisto[i][bin] ) maxBin = potHisto[i][bin];
	  	}
     	for ( int bin=0; bin<10; bin++ )	
     		g.fillRect( 20+4*bin, 100 - potHisto[i][bin], 24+4*bin, potHisto[i][bin] );
	  }
//******  End histograms  *********
     // Paint screen
		if (offImage != null)
		{
			currentImage = offImage;
//			repaint();
		}
*/
		time++;
	 }
//		System.gc();
	     // Draw lables
//		if ( time == 1 ) 
		{
			Integer elapsedTime = new Integer(cycles );
			String str = elapsedTime.toString();
			g.drawString( str, 750, (HEIGHT-30+25) );
		}
		time=0; 
		cycles++;
	}
    
}
