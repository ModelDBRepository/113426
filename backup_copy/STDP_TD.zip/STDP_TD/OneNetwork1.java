/**
	A neural network made up of a pair of mutually coupled neurons.
	@author Patrick D. Roberts, Neuro. Sci. Inst. OHSU, 04/01 (Supported by R01-MH60364) 
*/
import java.util.*;

 public class OneNetwork1 extends Network{
		protected int cycleLength;
		int cycleTime;
		TestWaveform testWave, testWave2;
		int NUMINPUTS;
	protected Random	inputRandomizer;
	double ran;
	double[] spikeHisto;
	int[][] spikeRaster;
	int sampleNum, maxCycles, cycIndex;
/**
	Initializes the network.
*/
  	public OneNetwork1(  ) {
  		NUMNEURONS = 3;
  		NUMINPUTS = 170;
//		module = new DualBellModule( NUMNEURONS, NUMINPUTS );
//		module = new DualBiModule( NUMNEURONS, NUMINPUTS );
		module = new DualFeldmanModule( NUMNEURONS, NUMINPUTS );
		cycleLength = 200;
		testWave = new TestWaveform();
		testWave2 = new TestWaveform(0);
		inputRandomizer = new Random();
		spikeHisto = new double[200];
		maxCycles = 500;
		cycIndex = 0;
		spikeRaster = new int[maxCycles][200];
  	}

/**
	Initiates one time step of the network.
*/
  	public void StepNetwork( int time ) {
  	cycleTime = time%cycleLength; 		
	for (int n=0; n<NUMNEURONS; n++) {
		if ( cycleTime == 0 ) {
			ran = inputRandomizer.nextDouble();
//			if (  ran < 0.0 ) module.setBaselinePot( n, testWave.getWaveform() );
//			else module.setBaselinePot( n, testWave2.getWaveform() );
		}
		if ( cycleTime<150 ) module.serialInput( n, cycleTime );
		else  {if ( ran < 0.9 ) module.serialInput( n, cycleTime );}		
		module.spikeINC( n, time );
//		module.spikeNonPlastINC( n );
	}
	module.synapticConnect(  0,  1, 10000 );
	module.synapticConnect(  0,  2, 5000 );
	module.synapticConnect(  1,  2, -5000 );
	//-- store and print histo ------   
		if ( getPostSpike(2) && time>100*200) spikeHisto[cycleTime]++;  
		if ( time%(1100*200)==0 && time>500*200){
			sampleNum++;
			System.out.println( "" );
			System.out.println( "sample"+sampleNum );
			for (int i=0; i<cycleLength; i++) {
	  			System.out.println( spikeHisto[i]/1000 );
	  			spikeHisto[i] = 0;
	  		}
		}
	//-- end histo ------   
	//-- store and print raster ------   
		if ( getPostSpike(0)) spikeRaster[cycIndex][cycleTime] = 1;
		else   spikeRaster[cycIndex][cycleTime] = 0;
		if ( cycleTime == 0 && time!=0) cycIndex++;
		if ( time%(maxCycles*200)==0 && time>0){
//			PrintSpkRaster();
			cycIndex=0;
		}
	//-- end raster ------   
  	}

/**
	Initiates one time step of the network changing a parameter with each trial.
*/
  	public void StepNetwork( int time, int trial ) {
		StepNetwork( time );
  	}

/** 
  * A method to write the results.
  */
  	public void PrintSpkRaster() {
	 	double numSpikes;
	  	for ( int i=0; i < cycleLength; i++ ) {
	  		for ( int c=0; c < maxCycles; c++ ) {
	  			numSpikes = spikeRaster[c][i];
				System.out.print(numSpikes + "	");
			}
			System.out.println("");
		}
 	}
}

/********************************************************************* 
  * A private class to create a module of two mutually coupled neurons
  * with a [Feldman00] learning rule.
*/
class DualFeldmanModule extends Module{

/**
	Create a Module with numNeurons neurons plastic synaptic inputs following the [Feldman00] rule.
*/
	public DualFeldmanModule( int numNeurons, int initNumInputSyns  ) {
		randomizer = new Random();
		funct = new HandyFuncts();
		epspWave = funct.GammaWave(  10, 70, 1, 0, false  );  //***  delay series input *****
		ipspWave = funct.GammaWave(  10, -150, 2, 0, false  );  //***  delay series input *****
		int lambda = 20;
		ruleWaveF = funct.GammaWave(  20,  lambda*100, 1, 0, false  );
		ruleWaveB = funct.GammaWave(  20, -lambda*150, 1, 0, false  );		
		ruleWave = ruleWaveF.getMerge( ruleWaveB, ruleWaveF );
		Waveform nullWave = new Waveform(1);
		int nonassociative = lambda*0;	
		
		noise = 90; thresh = 30;
		neuron = new Soma[numNeurons];
		for ( int num=0; num<numNeurons; num++ ) {
			neuron[num] = new Soma( noise, thresh );
			neuron[num].setEpsp( epspWave );
			neuron[num].setIpsp( ipspWave );
			neuron[num].setBias( 000 );
			if ( num==2 ) neuron[num].setBias( 500 );
			neuron[num].setRefractory( 0 );
			neuron[num].setDiffPot( 15 );
		}
		numInputSyns = initNumInputSyns;
		synapse = new PostSynapse[numNeurons][numInputSyns];
		for ( int i=0; i<numNeurons; i++ ) {
		  for ( int j=0; j<numInputSyns; j++ ) {
		  if (j<150 && i==0) {
				synapse[i][j] = new PostSynapse( (int) (1000+000*randomizer.nextGaussian()), 1, ruleWave, nonassociative, 0 );
				synapse[i][j].setRule( ruleWaveB, ruleWaveF, nonassociative  );
			}
			if (j>=150 &&  i==0 ) {
				synapse[i][j] = new PostSynapse( 5000, 1, ruleWave, nonassociative, 0 );
//				synapse[i][j] = new PostSynapse( (int) (000+000*randomizer.nextGaussian()), 1, ruleWave, nonassociative, 0 );
//				synapse[i][j].setRule( ruleWaveB, ruleWaveF, nonassociative  );
//				synapse[i][j] = new PostSynapse( 4500 + 50*(j-150), 1, ruleWave, nonassociative, 0 );
				synapse[i][j].setRule( nullWave, nullWave, 0  );
			}
			if ( i==1 ) {
				synapse[i][j] = new PostSynapse( 0, 1, ruleWave, nonassociative, 0 );
				synapse[i][j].setRule( nullWave, nullWave, 0  );
			}
			if ( i==2 ) {
				synapse[i][j] = new PostSynapse( 0, 1, ruleWave, nonassociative, 0 );
				synapse[i][j].setRule( nullWave, nullWave, 0  );
			}
		  }
		}
		preSpike = new boolean[numNeurons][numInputSyns];
		postSpike = new boolean[numNeurons];
	}
/**
	Simple synaptic interaction between neurons in the Module.
	@param preNeuron Presynaptic neuron.
	@param postNeuron Postsynaptic neuron.
	@param strength Synaptic strength of connection (If strength>=0 => epsp, else ipsp).
*/
	public void synapticConnect( int preNeuron, int postNeuron, int strength ) {
		if ( strength >= 0 ) {
			if ( postSpike[preNeuron]  ) neuron[postNeuron].epspInput( strength  );
		}
		else{
			if ( postSpike[preNeuron]  ) neuron[postNeuron].ipspInput( -strength  ); 
		}
	}
}

class TestWaveform {
	Waveform wave;
/**
	Class constructor default.
*/
	public TestWaveform() {
		 wave = new Waveform( 200 );
		wave = new Waveform( 200 );
		HandyFuncts funct = new HandyFuncts();
		Waveform gWave = funct.gaussianWave( 5, 100, 150 );
		int gaussianLength = gWave.getLength();
		for (int i=0; i<gaussianLength; i++) wave.setWavePt( 100*gWave.getWavePt(i), i );
	}
/**
	Class constructor default.
*/
	public TestWaveform( int scale) {
		 wave = new Waveform( 200 );
		wave = new Waveform( 200 );
		HandyFuncts funct = new HandyFuncts();
		Waveform gWave = funct.gaussianWave( 20, scale, 130 );
		Waveform gWave2 = funct.gaussianWave( 20, scale, 100 );
		int gaussianLength = gWave.getLength();
		for (int i=0; i<gaussianLength; i++) wave.setWavePt( 50*gWave.getWavePt(i), i );
	}
/**
	Returns a waveform.
*/
	public Waveform getWaveform( ) {
		return wave;
	}

}