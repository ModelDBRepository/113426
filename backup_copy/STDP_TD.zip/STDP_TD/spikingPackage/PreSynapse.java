/**
	A spike relay with a weight that can change according to the recent history of spikes in a Soma.
	@author Patrick D. Roberts, Neuro. Sci. Inst. OHSU, 11/00 (Supported by R01-MH60364) 
*/
import java.util.*;

public class PreSynapse {
	private StreamingData spikeTrain;	// Record of spikes.
	private Waveform facilitation;		// facilitation rule
	private Waveform depression;		// depression rule
	private int stWeight;				// Weight adjusted by short-term processes (facillitating/depressing).
	private int delay;					// Axonal delay for spike to reach synapse from soma.
	
/**
	Class constructor default.
*/
	public PreSynapse() {
		spikeTrain = new StreamingData();
		facilitation = new Waveform();
		depression = new Waveform();
		stWeight = 100;
		delay = 0;
	}
	
/**
	Class constructor that sets the noise and spike threshold.  
	@param initFacil The initial facilitation rule.
	@param initDepress The initial depression rule.
*/
	public PreSynapse( Waveform initFacil, Waveform initDepress ) {
		spikeTrain = new StreamingData();
		setFacilitation( initFacil );
		setDepression( initDepress );
		stWeight = 100;
		delay = 0;
	}
	
/**
	Sets the facilitation rule wavefrom.
	@param newFacil The new facilitation rule.
*/
	public void setFacilitation( Waveform newFacil ) {
		facilitation = newFacil;
	}
	
/**
	Sets the depression rule wavefrom.
	@param newDepress The new depression rule.
*/
  	public void setDepression( Waveform newDepress  ) {
		depression = newDepress;
  	}
/**
	Returns the facilitation rule wavefrom.
*/
  	public Waveform getFacilitation(  ) {
		return facilitation;
  	}
/**
	Returns the depression rule wavefrom.
*/
  	public Waveform getDepression(  ) {
		return depression;
  	}
/**
	Sets the axonal delay.
	@param newDepress The new depression rule.
*/
  	public void setDelay( int newDelay  ) {
		delay = newDelay;
  	}
/**
	Sets a presynaptic soma spike at time='now'and INCREMENTS.
	@param somaSpike The presence of a presynaptic spike.
*/
  	public void setSpikeINC( boolean somaSpike ) {
  		int spike = 0;
  		if ( somaSpike ) spike = stWeight; 
  		spikeTrain.setDatum( spike );
  	}

/**
	Relays a presynaptic soma spike.
*/
  	public boolean getSpike( ) {
  		int spike = spikeTrain.getDatum( );
  		if ( spike > 0 ) return true; 
  		else return false;
  	}
/**
	Returns the short-term weight of a presynaptic soma spike.
*/
  	public int getWeight( ) {
  		return spikeTrain.getDatum( );
  	}
}

